"""LungLens web app / REST API.

    python app.py                                    # dev server on http://127.0.0.1:8080
    gunicorn -b 0.0.0.0:8080 --timeout 120 app:app   # production (Linux/macOS)

Environment variables:
    PORT / HOST             bind address for `python app.py` (default 8080 / 127.0.0.1)
    LUNGLENS_HOME           workspace holding artifacts/ (default: project folder)
    LUNGLENS_API_KEY        if set, POST endpoints require the header  X-API-Key: <key>
    LUNGLENS_CORS_ORIGINS   comma-separated allowed origins, or * (default: CORS disabled)
"""
import hmac
import io
import os

from flask import Flask, jsonify, render_template, request
from PIL import Image, UnidentifiedImageError
from werkzeug.exceptions import HTTPException

from lunglens.components.predictor import Predictor
from lunglens.config.configuration import ConfigurationManager
from lunglens.constants import DISCLAIMER
from lunglens.exception import ImageQualityError, LungLensError, ModelNotReadyError
from lunglens.logger import logger
from lunglens.utils import decode_image_bytes

Image.MAX_IMAGE_PIXELS = 50_000_000  # decompression-bomb guard
MAX_BATCH = 16
_TRUE = {"1", "true", "yes", "on"}


class BadRequest(Exception):
    pass


def _open_image(raw: bytes) -> Image.Image:
    try:
        image = Image.open(io.BytesIO(raw))
        image.load()
        return image
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError):
        raise BadRequest("That file could not be read as an image.")


def _wants_explain() -> bool:
    return str(request.args.get("explain") or request.form.get("explain") or "").lower() in _TRUE


def create_app(predictor: Predictor = None) -> Flask:
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16 MB upload cap
    predictor = predictor or Predictor(ConfigurationManager().get_prediction_config())
    api_key = os.getenv("LUNGLENS_API_KEY")
    origins = [o.strip() for o in os.getenv("LUNGLENS_CORS_ORIGINS", "").split(",") if o.strip()]

    @app.before_request
    def _auth():
        if api_key and request.method == "POST":
            if not hmac.compare_digest(request.headers.get("X-API-Key", ""), api_key):
                return jsonify(error="Missing or invalid API key."), 401

    @app.after_request
    def _headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Cache-Control"] = "no-store"
        if origins:
            origin = request.headers.get("Origin", "")
            if "*" in origins:
                resp.headers["Access-Control-Allow-Origin"] = "*"
            elif origin in origins:
                resp.headers["Access-Control-Allow-Origin"] = origin
                resp.headers["Vary"] = "Origin"
            resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-API-Key"
        return resp

    @app.errorhandler(BadRequest)
    def _bad(e):
        return jsonify(error=str(e)), 400

    @app.errorhandler(413)
    def _too_large(e):
        return jsonify(error="File too large (limit 16 MB)."), 413

    @app.errorhandler(404)
    def _nf(e):
        return jsonify(error="Not found."), 404

    @app.errorhandler(405)
    def _mna(e):
        return jsonify(error="Method not allowed."), 405

    @app.errorhandler(ModelNotReadyError)
    def _not_ready(e):
        return jsonify(error=str(e)), 503

    @app.errorhandler(ImageQualityError)
    def _quality(e):
        return jsonify(error=str(e), code="image_rejected"), 422

    @app.errorhandler(LungLensError)
    def _app_error(e):
        return jsonify(error=str(e)), 400

    @app.errorhandler(Exception)
    def _unexpected(e):
        if isinstance(e, HTTPException):  # e.g. malformed multipart -> keep the proper 4xx status
            return jsonify(error=e.description), e.code
        logger.exception("Unhandled error")
        return jsonify(error="Internal server error."), 500

    # ---------------------------------------------------------------- routes
    @app.get("/")
    def home():
        # Show the project homepage when the app is opened.
        return render_template("home.html")

    @app.get("/analyze")
    def analyze_page():
        # The analysis page contains the image upload and prediction interface.
        return render_template("index.html")

    @app.get("/home")
    def landing_page():
        # Keep /home available as another way to open the homepage.
        return render_template("home.html")

    @app.get("/health")
    def health():
        return jsonify(status="ok", model_ready=predictor.is_ready)

    @app.get("/model-info")
    def model_info():
        return jsonify(predictor.model_info())

    @app.post("/predict")
    def predict():
        """multipart form-data field 'file', or JSON {"image": "<base64 or data-URL>"}. Add ?explain=1 for a heatmap."""
        if "file" in request.files:
            raw = request.files["file"].read()
        else:
            payload = request.get_json(silent=True) or {}
            if not payload.get("image"):
                raise BadRequest("Send an image as form field 'file' or JSON key 'image'.")
            try:
                raw = decode_image_bytes(payload["image"])
            except ValueError:
                raise BadRequest("'image' is not valid base64.")
        return jsonify(predictor.predict(_open_image(raw), explain=_wants_explain()))

    @app.post("/predict/batch")
    def predict_batch():
        """multipart form-data with several 'files' fields (max 16). Each file succeeds or fails independently."""
        files = request.files.getlist("files")
        if not files:
            raise BadRequest("Send one or more images as form field 'files'.")
        if len(files) > MAX_BATCH:
            raise BadRequest(f"At most {MAX_BATCH} images per request.")
        results = []
        for f in files:
            entry = {"filename": f.filename}
            try:
                entry.update(predictor.predict(_open_image(f.read())))
            except (BadRequest, ImageQualityError) as e:
                entry["error"] = str(e)
            results.append(entry)
        return jsonify(count=len(results), results=results, disclaimer=DISCLAIMER)

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host=os.getenv("HOST", "127.0.0.1"), port=int(os.getenv("PORT", 8080)), debug=False)
