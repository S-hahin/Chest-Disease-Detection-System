# LungLens

Chest CT slice classification with a complete, tested ML workflow: **data ingestion → training →
evaluation → REST API + web UI**, with uncertainty flags, input-quality checks and explanations.

> **Disclaimer:** educational/research project, **not a medical device**. Never use it for diagnosis
> or treatment decisions.

## What it does

Given a chest CT slice (JPG/PNG/BMP/TIFF) it predicts one of the dataset's classes (by default the four
classes of the public *Chest CT-Scan images* dataset: adenocarcinoma, large cell carcinoma,
squamous cell carcinoma, normal) and returns:

* the predicted class and per-class probabilities,
* an **"uncertain" flag** (low top probability or a small margin between the top two classes),
* an **occlusion heatmap** showing which image regions the model was sensitive to,
* **input-quality checks** - blank, tiny or colour-photo uploads are rejected instead of getting a confident label.

### Two interchangeable model backends

| Backend | What it is | Needs | Status in this release |
|---|---|---|---|
| `classic` (default) | Hand-crafted features (HOG, LBP, GLCM texture, intensity statistics) + scikit-learn ensemble (logistic regression + RBF-SVM + gradient boosting, soft voting) | CPU only, no downloads | **Fully tested** (78 automated tests) |
| `keras` | ImageNet transfer learning (EfficientNetB0 / DenseNet121 / ResNet50V2), 2-phase training (head, then fine-tuning) | TensorFlow (`requirements-deep.txt`) + internet for pretrained weights | Implemented, **not executed** by the author (see *Verification status*) |

Switch with `BACKEND:` in `params.yaml`. Everything else (data handling, evaluation, API, UI, explanations)
is backend-agnostic.

## Quick start (included offline demo)

This project ZIP includes a trained **classic ML model** and a small synthetic CT-like dataset, so it can
be tested without downloading a dataset.

```bash
python -m venv .venv
source .venv/bin/activate              # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python app.py
# open http://127.0.0.1:8080
# upload a PNG from data/synthetic_ct/test/<class>/
```

The bundled model was rebuilt with **scikit-learn 1.8.0**, which is pinned in `requirements.txt` so the
saved model is loaded with the compatible library version. If you want to retrain it, run:

```bash
python main.py train
python main.py evaluate
```

The included images are synthetic and are intended only to verify that the software pipeline works.

The demo takes well under a minute on a laptop CPU and writes everything to `./demo_workspace`
(your real `data/` and `artifacts/` folders are untouched). Its images are synthetic and easy by design -
**the near-perfect score means nothing about real-world performance.**
To serve the demo model later: `LUNGLENS_HOME=demo_workspace python app.py`
(PowerShell: `$env:LUNGLENS_HOME='demo_workspace'; python app.py`).

## Using the real dataset

```bash
python main.py                          # ingest -> train -> evaluate, downloading from config.yaml's source_url
python main.py ingest --local dataset.zip   # a manually downloaded zip ...
python main.py ingest --local ./my_folder   # ... or an already-extracted folder
python main.py train
python main.py evaluate
python main.py predict scan.png --explain   # CLI prediction, saves scan_heatmap.png
python app.py                           # web UI + API on http://127.0.0.1:8080
```

**Downloads:** the previous `gdown` dependency was replaced by a small standard-library downloader
(`lunglens/components/downloader.py`): retries with back-off, `.part` files, optional SHA-256 check,
refuses HTML error pages, follows Google Drive's "large file" confirmation page. Drive changes that page
from time to time and quota limits happen; if the download fails you get instructions, and
`--local` always works. Set `data_ingestion.archive_sha256` in `config/config.yaml` to verify downloads.

**Supported folder layouts** (auto-detected, class count read from the folders):

```
Data/train/<class>/*.jpg   Data/valid/<class>/*.jpg   [Data/test/<class>/*.jpg]   pre-split
<any-name>/<class>/*.jpg                                                          flat -> stratified train/valid/test split
```

In pre-split data, class folders in `valid/` and `test/` may use short names (`adenocarcinoma` for
`adenocarcinoma_left.lower.lobe_T2_N0_M0_Ib`) - they are matched to the training classes automatically.
Evaluation always uses the held-out **test** split when one exists (otherwise the validation split),
and the code refuses to run if a file appears in both training and evaluation data.

## Configuration

* `params.yaml` - image size, splits, seed, backend, per-backend hyper-parameters, `CV_FOLDS`,
  `CONFIDENCE_THRESHOLD`, `MIN_MARGIN`, `QUALITY_CHECK`, `EXPLAIN_GRID`. Values are validated with clear errors.
* `config/config.yaml` - folders, dataset URL, checksum, download retries/timeouts.
* Environment: `LUNGLENS_HOME` (workspace for `data/` + `artifacts/`), `LUNGLENS_API_KEY`,
  `LUNGLENS_CORS_ORIGINS`, `LUNGLENS_LOG_LEVEL`, `LUNGLENS_LOG_DIR`, `PORT`, `HOST`.

For the Keras backend: `pip install -r requirements-deep.txt`, then in `params.yaml` set
`BACKEND: keras` and `IMAGE_SIZE: [224, 224]`.

## Outputs

| File | Content |
|---|---|
| `artifacts/model/` | trained model, `class_names.json`, `history.json`, **`model_card.json`** (backend, parameters, class counts, dataset fingerprint, CV result, library versions, evaluation summary) |
| `artifacts/reports/scores.json` | accuracy, balanced accuracy, macro/weighted F1, Matthews corr., ROC-AUC (one-vs-rest), log-loss, expected calibration error, per-class precision/recall/F1, top confusions |
| `artifacts/reports/classification_report.txt`, `confusion_matrix.png` | per-class report; counts + row-normalised matrix |

Training runs stratified k-fold cross-validation (`CV_FOLDS`, default 3) on the training split and stores the
result in the model card. Evaluation warns if the dataset/split changed since training.

## REST API

```bash
curl -F "file=@scan.png" "http://localhost:8080/predict?explain=1"
curl -X POST -H "Content-Type: application/json" -d '{"image":"<base64 or data-URL>"}' http://localhost:8080/predict
curl -F "files=@a.png" -F "files=@b.png" http://localhost:8080/predict/batch     # up to 16 images
curl http://localhost:8080/health ; curl http://localhost:8080/model-info
```

| Status | Meaning |
|---|---|
| 200 | prediction |
| 400 | unreadable image / bad request |
| 401 | missing/invalid `X-API-Key` (only if `LUNGLENS_API_KEY` is set; applies to POST) |
| 413 | upload larger than 16 MB |
| 422 | image rejected by the quality check (blank, < 64 px, colour photo) |
| 503 | no trained model yet |

Example response (abridged): `{"label": "Normal", "confidence": 0.93, "margin": 0.88, "uncertain": false,
"uncertain_reasons": [], "probabilities": [...], "quality_warnings": [], "model": {...},
"explanation": {"method": "occlusion-sensitivity", "heatmap_png_base64": "..."}}`.
CORS is off by default; set `LUNGLENS_CORS_ORIGINS` (comma-separated origins or `*`) to enable it.

## Tests

```bash
python -m unittest discover -s tests -t .      # no pytest, network or TensorFlow required
python -m pytest tests                          # also works if pytest is installed (requirements-dev.txt)
```

78 tests cover: config validation; the downloader (against a local HTTP server: checksums, HTML pages,
404 vs. retried 503, emulated Drive confirmation page); ingestion (zip / folder / URL / synthetic, zip-slip
protection, corrupt downloads); dataset layouts and split hygiene; preprocessing (16-bit, RGBA);
quality checks; features; occlusion heatmaps (against a toy model whose sensitive region is known);
metrics; the full train → evaluate → predict flow; every API endpoint and error path; the CLI.
One further test (Keras round-trip) runs only if TensorFlow is installed.

## Docker

```bash
python main.py                         # train first; ./artifacts is copied into the image
docker build -t lunglens .
docker run -p 8080:8080 lunglens       # or mount:  -v "$(pwd)/artifacts:/app/artifacts:ro"
```

## Project layout

```
main.py                CLI: all | ingest | train | evaluate | predict | demo | serve
app.py                 Flask app + REST API             templates/index.html   web UI
config/config.yaml     paths, dataset URL               params.yaml            all hyper-parameters
lunglens/
  components/          downloader, data_ingestion, synthetic, dataset, preprocessing, quality, features,
                       metrics, trainer, evaluator, explain, predictor
  components/backends/ base, classic (scikit-learn), keras_backend (optional)
  config/              ConfigurationManager + typed config classes    pipeline/  ingest / train / evaluate stages
tests/                 offline test-suite               Dockerfile, Makefile, .github/workflows/ci.yml
```

## Verification status (please read)

Verified by running the bundled offline model and the train → evaluate → predict pipeline (Python 3.13, Linux, CPU); `python main.py demo`;
the complete CLI flow `python main.py --home X all --local <zip>` on a dataset in the public dataset's
folder layout; the running Flask server queried with `curl` (predict, explain, batch, error paths).

**Not verified - be aware:**
* **The Keras backend** has never been executed (no TensorFlow where this was built). It follows the Keras 3 API,
  and importing it without TensorFlow gives an install hint (tested), but expect that you may need to fix small issues.
* **The live Google Drive download** was not tested (no internet). The downloader is tested against local servers,
  including one that imitates Drive's confirmation page; the real Drive page may differ.
* **Accuracy on the real chest-CT dataset is unknown.** All reported scores are on synthetic images. Hand-crafted
  features are a modest baseline for real CT; for real data the `keras` backend is the better bet, and any result
  should be judged on the held-out test split, ideally with patient-level splitting (the public dataset has no
  patient IDs, so slices of the same patient can leak across splits and inflate scores).
* Only Python 3.12 was used for testing (`requirements.txt` lower bounds are minimums the code needs, not tested versions);
  `gunicorn` and Docker were not run; the GitHub Actions workflow has not been run.
* The occlusion heatmap shows what the *model* is sensitive to. With the classic backend, which uses global features,
  the map can be diffuse. It is not a clinical localisation.
* `joblib` model files are pickles: only load models you trained or trust.

## Attribution

