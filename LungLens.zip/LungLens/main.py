"""LungLens command line.

    python main.py                       # ingest -> train -> evaluate (same as `all`)
    python main.py demo                  # offline demo on synthetic data in ./demo_workspace
    python main.py ingest --local X.zip  # use a manually downloaded dataset (zip or folder)
    python main.py ingest --synthetic    # generate a synthetic dataset instead of downloading
    python main.py train | evaluate
    python main.py predict scan.png [--explain]
    python main.py serve                 # web app (same as `python app.py`)
"""
import argparse
import json
import os
import sys
from pathlib import Path

from lunglens.constants import ROOT
from lunglens.exception import LungLensError
from lunglens.logger import logger


def _manager(overrides=None):
    from lunglens.config.configuration import ConfigurationManager
    return ConfigurationManager(param_overrides=overrides)


def cmd_ingest(args) -> None:
    from lunglens.pipeline import data_ingestion
    root = data_ingestion.main(_manager(), local=args.local, url=args.url, synthetic=args.synthetic,
                               per_class=args.per_class, force=args.force)
    logger.info("Dataset ready at %s", root)


def cmd_train(args) -> None:
    from lunglens.pipeline import train
    train.main(_manager())


def cmd_evaluate(args) -> None:
    from lunglens.pipeline import evaluate
    scores = evaluate.main(_manager())
    print(json.dumps({k: v for k, v in scores.items() if k not in ("per_class", "top_confusions")}, indent=2))


def cmd_all(args) -> None:
    cmd_ingest(args)
    cmd_train(args)
    cmd_evaluate(args)


def cmd_predict(args) -> None:
    from PIL import Image
    from lunglens.components.predictor import Predictor
    predictor = Predictor(_manager().get_prediction_config())
    for path in args.images:
        with Image.open(path) as im:
            im.load()
        res = predictor.predict(im, explain=args.explain)
        heat = res.pop("explanation", None)
        print(f"\n{path}\n  -> {res['label']}  ({res['confidence']:.1%})" + ("  [UNCERTAIN]" if res["uncertain"] else ""))
        for reason in res["uncertain_reasons"] + res["quality_warnings"]:
            print(f"     ! {reason}")
        for p in res["probabilities"]:
            print(f"     {p['probability']:6.1%}  {p['label']}")
        if heat:
            import base64
            out = Path(args.heatmap_dir or ".") / (Path(path).stem + "_heatmap.png")
            out.write_bytes(base64.b64decode(heat["heatmap_png_base64"]))
            print(f"     heatmap saved to {out}")
    print(f"\n{res['disclaimer']}")


def cmd_demo(args) -> None:
    from lunglens.config.configuration import ConfigurationManager
    home = Path(args.home or ROOT / "demo_workspace").resolve()
    os.environ["LUNGLENS_HOME"] = str(home)
    manager = ConfigurationManager(root=home, param_overrides={"CV_FOLDS": 0})
    from lunglens.pipeline import data_ingestion, evaluate, train
    logger.info("Demo workspace: %s", home)
    data_ingestion.main(manager, synthetic=True, per_class=args.per_class)
    train.main(manager)
    scores = evaluate.main(manager)
    print(f"\nDemo finished. Accuracy on the synthetic test split: {scores['accuracy']:.1%} "
          "(synthetic images are easy by design - this says nothing about real CT performance).")
    print(f"Start the web app with:\n    LUNGLENS_HOME={home} python app.py      (Windows PowerShell: $env:LUNGLENS_HOME='{home}'; python app.py)")
    if args.serve:
        cmd_serve(args)


def cmd_serve(args) -> None:
    from app import create_app
    create_app().run(host=args.host, port=args.port, debug=False)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="lunglens", description="LungLens - chest CT slice classification")
    parser.add_argument("--home", help="workspace folder for data/ and artifacts/ (default: project folder)")
    sub = parser.add_subparsers(dest="command")

    def add_ingest_flags(p):
        p.add_argument("--local", help="path to a dataset .zip or an already-extracted folder")
        p.add_argument("--url", help="download from this URL instead of the one in config.yaml")
        p.add_argument("--synthetic", action="store_true", help="generate a synthetic demo dataset")
        p.add_argument("--per-class", type=int, default=60, help="images per class for --synthetic (default 60)")
        p.add_argument("--force", action="store_true", help="ingest even if a dataset is already present")

    for name, fn, help_ in (("all", cmd_all, "ingest -> train -> evaluate (default)"),
                            ("ingest", cmd_ingest, "obtain the dataset")):
        p = sub.add_parser(name, help=help_)
        add_ingest_flags(p)
        p.set_defaults(func=fn)
    sub.add_parser("train", help="train the model").set_defaults(func=cmd_train)
    sub.add_parser("evaluate", help="evaluate on the held-out split").set_defaults(func=cmd_evaluate)

    p = sub.add_parser("predict", help="classify image files from the command line")
    p.add_argument("images", nargs="+")
    p.add_argument("--explain", action="store_true", help="also save an occlusion heatmap")
    p.add_argument("--heatmap-dir", help="where to write heatmaps (default: current folder)")
    p.set_defaults(func=cmd_predict)

    p = sub.add_parser("demo", help="offline end-to-end demo on synthetic data")
    p.add_argument("--per-class", type=int, default=60)
    p.add_argument("--serve", action="store_true", help="start the web app afterwards")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8080)
    p.set_defaults(func=cmd_demo)

    p = sub.add_parser("serve", help="run the web app")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8080)
    p.set_defaults(func=cmd_serve)
    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.home:
        os.environ["LUNGLENS_HOME"] = str(Path(args.home).resolve())
    if not getattr(args, "func", None):  # bare `python main.py`
        args = parser.parse_args([*(argv if argv is not None else sys.argv[1:]), "all"])
    try:
        args.func(args)
    except LungLensError as e:
        logger.error("%s", e)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
