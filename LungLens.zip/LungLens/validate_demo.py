"""Validate the bundled offline model against one test image from each synthetic class."""
from pathlib import Path
from PIL import Image
from lunglens.config.configuration import ConfigurationManager
from lunglens.components.predictor import Predictor

ROOT = Path(__file__).resolve().parent
manager = ConfigurationManager(root=ROOT)
predictor = Predictor(manager.get_prediction_config())

# Always validate against a model built in the current environment. This prevents
# stale NumPy/scikit-learn joblib files from a different machine from being used.
predictor._bootstrap_demo_model()

test_root = ROOT / "data" / "synthetic_ct" / "test"
correct = 0
total = 0
for class_dir in sorted(p for p in test_root.iterdir() if p.is_dir()):
    image_path = next(class_dir.glob("*.png"))
    result = predictor.predict(Image.open(image_path))
    total += 1
    ok = result["raw_label"] == class_dir.name
    correct += int(ok)
    print(f"{class_dir.name} -> {result['raw_label']} ({result['confidence']:.1%})")
if correct != total:
    raise SystemExit(f"Validation failed: {correct}/{total} correct")
print(f"Validation passed: {correct}/{total} classes correct.")
