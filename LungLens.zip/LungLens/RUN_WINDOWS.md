# LungLens — Windows setup

If the project folder was moved after creating `.venv`, **do not reuse the old `.venv`**. Windows virtual-environment launchers contain absolute paths.

## Recommended setup (Python 3.8)

Open PowerShell in the LungLens folder:

```powershell
Remove-Item -Recurse -Force .venv -ErrorAction SilentlyContinue
py -3.8 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Then validate:

```powershell
.\.venv\Scripts\python.exe validate_demo.py
```

The first validation rebuilds the synthetic demo model using the libraries installed in this environment. This avoids incompatible joblib files created by a different NumPy/scikit-learn version.

Expected ending:

```text
Validation passed: 4/4 classes correct.
```

Start the web app:

```powershell
.\.venv\Scripts\python.exe app.py
```

Then open `http://127.0.0.1:8080`.

## Important

The bundled dataset is synthetic and is only for demonstrating the software pipeline. It is not a real clinical CT dataset, so predictions on real CT scans must not be treated as medical diagnoses.
