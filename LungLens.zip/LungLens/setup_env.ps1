$ErrorActionPreference = "Stop"
Write-Host "Creating a fresh LungLens virtual environment..."
if (Test-Path .venv) { Remove-Item -Recurse -Force .venv }
py -3.8 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Write-Host "Environment ready. Run: .\.venv\Scripts\python.exe validate_demo.py"
