from lunglens.components.evaluator import Evaluator
from lunglens.config.configuration import ConfigurationManager


def main(manager: ConfigurationManager = None) -> dict:
    manager = manager or ConfigurationManager()
    return Evaluator(manager.get_evaluation_config()).run()


if __name__ == "__main__":
    main()
