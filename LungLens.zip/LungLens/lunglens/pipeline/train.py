from lunglens.components.trainer import Trainer
from lunglens.config.configuration import ConfigurationManager


def main(manager: ConfigurationManager = None) -> dict:
    manager = manager or ConfigurationManager()
    return Trainer(manager.get_training_config()).run()


if __name__ == "__main__":
    main()
