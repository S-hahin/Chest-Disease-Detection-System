from lunglens.components.data_ingestion import DataIngestion
from lunglens.config.configuration import ConfigurationManager


def main(manager: ConfigurationManager = None, **kwargs):
    """kwargs: local=, url=, synthetic=, per_class=, force= (see DataIngestion.run)."""
    manager = manager or ConfigurationManager()
    return DataIngestion(manager.get_data_ingestion_config()).run(**kwargs)


if __name__ == "__main__":
    main()
