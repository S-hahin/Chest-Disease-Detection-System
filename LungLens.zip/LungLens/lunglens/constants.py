import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_FILE_PATH = ROOT / "config" / "config.yaml"
PARAMS_FILE_PATH = ROOT / "params.yaml"
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
DISCLAIMER = (
    "Educational/research project - not a medical device. "
    "Outputs must not be used for diagnosis or treatment decisions."
)


def workspace_root() -> Path:
    """Folder holding data/ and artifacts/. Override with the LUNGLENS_HOME env variable."""
    return Path(os.getenv("LUNGLENS_HOME", ROOT)).resolve()
