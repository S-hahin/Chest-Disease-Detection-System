from pathlib import Path
from typing import Optional

from lunglens.config.entity import (
    DataIngestionConfig,
    EvaluationConfig,
    PredictionConfig,
    TrainingConfig,
)
from lunglens.constants import CONFIG_FILE_PATH, PARAMS_FILE_PATH, workspace_root
from lunglens.exception import ConfigError
from lunglens.utils import read_yaml

BACKENDS = ("classic", "keras")


class ConfigurationManager:
    """Reads config.yaml + params.yaml, validates them and hands out typed config objects.

    Paths inside config.yaml are relative to ``root``: the project folder by default,
    or the ``LUNGLENS_HOME`` environment variable when set.
    ``param_overrides`` lets callers (tests, the demo command) tweak params.yaml values in memory.
    """

    def __init__(self, config_path=CONFIG_FILE_PATH, params_path=PARAMS_FILE_PATH, root=None,
                 param_overrides: Optional[dict] = None):
        self.root = Path(root).resolve() if root else workspace_root()
        self.config = read_yaml(config_path)
        self.params = read_yaml(params_path)
        self.params.update(param_overrides or {})
        self._validate()

    # ---- helpers -------------------------------------------------------------------------
    def _p(self, rel) -> Path:
        return self.root / rel

    def _section(self, name: str) -> dict:
        section = self.config.get(name)
        if not isinstance(section, dict):
            raise ConfigError(f"config.yaml is missing the '{name}' section.")
        return section

    def _validate(self) -> None:
        p = self.params
        for key in ("IMAGE_SIZE", "VALIDATION_SPLIT", "TEST_SPLIT", "SEED", "BACKEND"):
            if key not in p:
                raise ConfigError(f"params.yaml is missing '{key}'.")
        size = p["IMAGE_SIZE"]
        if not (isinstance(size, (list, tuple)) and len(size) == 2 and all(int(s) >= 32 for s in size)):
            raise ConfigError("IMAGE_SIZE must be [height, width] with both values >= 32.")
        if str(p["BACKEND"]).lower() not in BACKENDS:
            raise ConfigError(f"BACKEND must be one of {BACKENDS}, got '{p['BACKEND']}'.")
        v, t = float(p["VALIDATION_SPLIT"]), float(p["TEST_SPLIT"])
        if not (0 < v < 0.5) or not (0 <= t < 0.5) or v + t >= 0.8:
            raise ConfigError("VALIDATION_SPLIT must be in (0, 0.5), TEST_SPLIT in [0, 0.5), and sum < 0.8.")
        if int(p.get("CV_FOLDS", 0)) == 1 or int(p.get("CV_FOLDS", 0)) < 0:
            raise ConfigError("CV_FOLDS must be 0 (off) or >= 2.")
        for key in ("CONFIDENCE_THRESHOLD", "MIN_MARGIN"):
            if not 0 <= float(p.get(key, 0)) <= 1:
                raise ConfigError(f"{key} must be between 0 and 1.")

    @property
    def _image_size(self):
        size = self.params["IMAGE_SIZE"]
        return (int(size[0]), int(size[1]))

    @property
    def _backend(self) -> str:
        return str(self.params["BACKEND"]).lower()

    # ---- typed configs -------------------------------------------------------------------
    def get_data_ingestion_config(self) -> DataIngestionConfig:
        c = self._section("data_ingestion")
        return DataIngestionConfig(
            data_dir=self._p(c["data_dir"]),
            archive_path=self._p(c["archive_path"]),
            source_url=c.get("source_url"),
            archive_sha256=c.get("archive_sha256"),
            download_retries=int(c.get("download_retries", 3)),
            download_timeout=int(c.get("download_timeout", 60)),
        )

    def _model_dir(self) -> Path:
        return self._p(self._section("training")["model_dir"])

    def get_training_config(self) -> TrainingConfig:
        model_dir = self._model_dir()
        backend_params = dict(self.params.get(self._backend) or {})
        return TrainingConfig(
            data_dir=self._p(self._section("data_ingestion")["data_dir"]),
            model_dir=model_dir,
            history_path=model_dir / "history.json",
            class_names_path=model_dir / "class_names.json",
            model_card_path=model_dir / "model_card.json",
            backend=self._backend,
            backend_params=backend_params,
            image_size=self._image_size,
            validation_split=float(self.params["VALIDATION_SPLIT"]),
            test_split=float(self.params["TEST_SPLIT"]),
            seed=int(self.params["SEED"]),
            cv_folds=int(self.params.get("CV_FOLDS", 0)),
            normalize_contrast=bool(self.params.get("NORMALIZE_CONTRAST", True)),
        )

    def get_evaluation_config(self) -> EvaluationConfig:
        model_dir = self._model_dir()
        return EvaluationConfig(
            data_dir=self._p(self._section("data_ingestion")["data_dir"]),
            model_dir=model_dir,
            class_names_path=model_dir / "class_names.json",
            model_card_path=model_dir / "model_card.json",
            report_dir=self._p(self._section("evaluation")["report_dir"]),
            validation_split=float(self.params["VALIDATION_SPLIT"]),
            test_split=float(self.params["TEST_SPLIT"]),
            seed=int(self.params["SEED"]),
            normalize_contrast=bool(self.params.get("NORMALIZE_CONTRAST", True)),
        )

    def get_prediction_config(self) -> PredictionConfig:
        model_dir = self._model_dir()
        return PredictionConfig(
            model_dir=model_dir,
            class_names_path=model_dir / "class_names.json",
            model_card_path=model_dir / "model_card.json",
            confidence_threshold=float(self.params.get("CONFIDENCE_THRESHOLD", 0.6)),
            min_margin=float(self.params.get("MIN_MARGIN", 0.1)),
            quality_check=bool(self.params.get("QUALITY_CHECK", True)),
            explain_grid=int(self.params.get("EXPLAIN_GRID", 8)),
            normalize_contrast=bool(self.params.get("NORMALIZE_CONTRAST", True)),
        )
