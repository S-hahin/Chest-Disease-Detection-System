from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple


@dataclass(frozen=True)
class DataIngestionConfig:
    data_dir: Path
    archive_path: Path
    source_url: Optional[str]
    archive_sha256: Optional[str]
    download_retries: int
    download_timeout: int


@dataclass(frozen=True)
class TrainingConfig:
    data_dir: Path
    model_dir: Path
    history_path: Path
    class_names_path: Path
    model_card_path: Path
    backend: str
    backend_params: dict
    image_size: Tuple[int, int]
    validation_split: float
    test_split: float
    seed: int
    cv_folds: int
    normalize_contrast: bool


@dataclass(frozen=True)
class EvaluationConfig:
    data_dir: Path
    model_dir: Path
    class_names_path: Path
    model_card_path: Path
    report_dir: Path
    validation_split: float
    test_split: float
    seed: int
    normalize_contrast: bool

    @property
    def scores_path(self) -> Path:
        return self.report_dir / "scores.json"

    @property
    def report_path(self) -> Path:
        return self.report_dir / "classification_report.txt"

    @property
    def confusion_matrix_path(self) -> Path:
        return self.report_dir / "confusion_matrix.png"


@dataclass(frozen=True)
class PredictionConfig:
    model_dir: Path
    class_names_path: Path
    model_card_path: Path
    confidence_threshold: float
    min_margin: float
    quality_check: bool
    explain_grid: int
    normalize_contrast: bool
