import logging
import logging.handlers
import os
from pathlib import Path

from lunglens.constants import ROOT

logger = logging.getLogger("lunglens")


def _configure() -> None:
    if logger.handlers:
        return
    logger.setLevel(os.getenv("LUNGLENS_LOG_LEVEL", "INFO").upper())
    fmt = logging.Formatter("[%(asctime)s] %(levelname)s %(name)s - %(message)s")
    console = logging.StreamHandler()
    console.setFormatter(fmt)
    logger.addHandler(console)
    try:  # file logging is best-effort (read-only containers, etc.)
        log_dir = Path(os.getenv("LUNGLENS_LOG_DIR", ROOT / "logs"))
        log_dir.mkdir(parents=True, exist_ok=True)
        fh = logging.handlers.RotatingFileHandler(
            log_dir / "lunglens.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8"
        )
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except OSError:
        pass
    logger.propagate = False


_configure()
