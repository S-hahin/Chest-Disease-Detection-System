import numpy as np
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    log_loss,
    matthews_corrcoef,
    roc_auc_score,
)

from lunglens.components.backends import get_backend_class
from lunglens.components.dataset import build_index, load_split
from lunglens.components.metrics import expected_calibration_error
from lunglens.config.entity import EvaluationConfig
from lunglens.exception import LungLensError
from lunglens.logger import logger
from lunglens.utils import fingerprint, humanize_label, load_json, save_json


def plot_confusion_matrix(cm, class_names, path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    labels = [humanize_label(n).split(" (")[0][:28] for n in class_names]
    norm = cm / np.maximum(cm.sum(axis=1, keepdims=True), 1)
    size = max(4.5, len(class_names) * 1.5)
    fig, axes = plt.subplots(1, 2, figsize=(size * 2, size))
    for ax, data, title, fmt in ((axes[0], cm, "Counts", "{:d}"), (axes[1], norm, "Row-normalised (recall)", "{:.2f}")):
        ax.imshow(data, cmap="Blues", vmin=0)
        ax.set_xticks(range(len(labels)))
        ax.set_yticks(range(len(labels)))
        ax.set_xticklabels(labels, rotation=40, ha="right")
        ax.set_yticklabels(labels)
        ax.set_xlabel("Predicted")
        ax.set_ylabel("True")
        ax.set_title(title)
        top = data.max() if data.max() > 0 else 1
        for i in range(data.shape[0]):
            for j in range(data.shape[1]):
                val = int(data[i, j]) if fmt == "{:d}" else data[i, j]
                ax.text(j, i, fmt.format(val), ha="center", va="center",
                        color="white" if data[i, j] > top / 2 else "black")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=140)
    plt.close(fig)


class Evaluator:
    """Scores the trained model on the held-out test split (or validation split if there is no test split)."""

    def __init__(self, config: EvaluationConfig):
        self.config = config

    @staticmethod
    def _renormalise(proba: np.ndarray) -> np.ndarray:
        clipped = np.clip(proba, 1e-7, 1.0)
        return clipped / clipped.sum(axis=1, keepdims=True)

    def run(self) -> dict:
        c = self.config
        if not (c.model_card_path.exists() and c.class_names_path.exists()):
            raise LungLensError(f"No trained model found in {c.model_dir}. Run `python main.py train` first.")
        card = load_json(c.model_card_path)
        class_names = load_json(c.class_names_path)["class_names"]
        size = tuple(card["image_size"])
        backend = get_backend_class(card["backend"]).load(c.model_dir, class_names, size)

        index = build_index(c.data_dir, c.validation_split, c.test_split, c.seed)
        if index.class_names != class_names:
            raise LungLensError("The dataset's classes differ from the classes the model was trained on.")
        current_fp = fingerprint(f"{p.name}:{y}" for p, y in index.train)
        if current_fp != card["dataset"]["train_fingerprint"]:
            logger.warning("The training split now differs from the one used for training (dataset or split "
                           "parameters changed) - scores may be optimistic. Retrain to be safe.")

        split_name, items = index.eval_split
        x, y_true = load_split(items, size, bool(card.get("normalize_contrast", True)))
        proba = backend.predict_proba(x)
        y_pred = proba.argmax(axis=1)
        labels = list(range(len(class_names)))

        report_txt = classification_report(y_true, y_pred, labels=labels, target_names=class_names, zero_division=0)
        report = classification_report(y_true, y_pred, labels=labels, target_names=class_names,
                                       zero_division=0, output_dict=True)
        cm = confusion_matrix(y_true, y_pred, labels=labels)

        try:
            auc = float(roc_auc_score(y_true, proba, multi_class="ovr", average="macro", labels=labels))
        except ValueError:  # a class is absent from the evaluation split
            auc = None
        confusions = sorted(
            ((class_names[i], class_names[j], int(cm[i, j])) for i in labels for j in labels if i != j and cm[i, j]),
            key=lambda t: -t[2])[:5]

        scores = {
            "evaluated_on": split_name,
            "samples": int(len(y_true)),
            "accuracy": float(accuracy_score(y_true, y_pred)),
            "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
            "macro_f1": float(f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0)),
            "weighted_f1": float(f1_score(y_true, y_pred, labels=labels, average="weighted", zero_division=0)),
            "matthews_corrcoef": float(matthews_corrcoef(y_true, y_pred)),
            "roc_auc_ovr_macro": auc,
            "log_loss": float(log_loss(y_true, self._renormalise(proba), labels=labels)),
            "expected_calibration_error": expected_calibration_error(proba, y_true),
            #"per_class": {n: {k: float(report[n][k]) for k in ("precision", "recall", "f1-score")} | {"support": int(report[n]["support"])}
            "per_class": {
                n: {
                    **{k: float(report[n][k]) for k in ("precision", "recall", "f1-score")},
                    "support": int(report[n]["support"])
                    }
                          for n in class_names},
            "top_confusions": [{"true": t, "predicted": p, "count": n} for t, p, n in confusions],
        }

        c.report_dir.mkdir(parents=True, exist_ok=True)
        c.report_path.write_text(report_txt, encoding="utf-8")
        plot_confusion_matrix(cm, class_names, c.confusion_matrix_path)
        save_json(c.scores_path, scores)

        card["evaluation"] = {k: scores[k] for k in ("evaluated_on", "samples", "accuracy", "balanced_accuracy",
                                                    "macro_f1", "roc_auc_ovr_macro")}
        save_json(c.model_card_path, card)
        logger.info("Evaluation on %s split (%d images): accuracy=%.3f macro_f1=%.3f\n%s",
                    split_name, len(y_true), scores["accuracy"], scores["macro_f1"], report_txt)
        return scores
