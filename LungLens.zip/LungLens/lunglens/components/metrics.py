import numpy as np


def entropy(probs: np.ndarray) -> float:
    """Shannon entropy in bits (0 = certain, log2(C) = uniform)."""
    p = np.clip(np.asarray(probs, dtype=np.float64), 1e-12, 1.0)
    return float(-(p * np.log2(p)).sum())


def expected_calibration_error(proba: np.ndarray, y_true: np.ndarray, n_bins: int = 10) -> float:
    """ECE: weighted gap between confidence and accuracy over confidence bins (0 = perfectly calibrated)."""
    conf = proba.max(axis=1)
    correct = (proba.argmax(axis=1) == y_true).astype(np.float64)
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (conf > lo) & (conf <= hi)
        if mask.any():
            ece += mask.mean() * abs(correct[mask].mean() - conf[mask].mean())
    return float(ece)
