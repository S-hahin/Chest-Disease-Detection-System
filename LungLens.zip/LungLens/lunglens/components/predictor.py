import threading
from typing import List, Optional

import numpy as np
from PIL import Image

from lunglens.components.backends import get_backend_class
from lunglens.components.explain import occlusion_heatmap, overlay_png_base64
from lunglens.components.metrics import entropy
from lunglens.components.preprocessing import to_gray_array
from lunglens.components.quality import assess_image
from lunglens.config.entity import PredictionConfig
from lunglens.constants import DISCLAIMER
from lunglens.exception import ImageQualityError, ModelNotReadyError
from lunglens.utils import humanize_label, load_json
from lunglens.logger import logger


class Predictor:
    """Lazily loads the trained model (once, thread-safe) and classifies single CT slices."""

    def __init__(self, config: PredictionConfig):
        self.config = config
        self._backend = None
        self._card: Optional[dict] = None
        self._class_names: Optional[List[str]] = None
        self._lock = threading.Lock()

    @property
    def is_ready(self) -> bool:
        return (self.config.model_card_path.exists() and
                self.config.class_names_path.exists() and
                (self.config.model_dir / "classic_model.joblib").exists())

    def _bootstrap_demo_model(self) -> None:
        """Train the bundled synthetic demo model in the current Python environment.

        Saved sklearn/joblib models are not reliably portable across NumPy/scikit-learn
        versions. Rebuilding from the included synthetic data avoids loading a stale
        pickle created in another environment.
        """
        from lunglens.components.trainer import Trainer
        from lunglens.config.configuration import ConfigurationManager

        root = self.config.model_dir.parent.parent
        manager = ConfigurationManager(root=root, param_overrides={"CV_FOLDS": 0})
        data_root = root / "data" / "synthetic_ct"
        if not data_root.exists():
            raise ModelNotReadyError(
                "No compatible model was found and the bundled synthetic dataset is missing. "
                "Run `python main.py ingest --synthetic` and then `python main.py train`."
            )
        Trainer(manager.get_training_config()).run()

    def _load(self) -> None:
        if self._backend is not None:
            return

        # If a model is missing or was created with incompatible NumPy/sklearn versions,
        # rebuild it locally from the bundled synthetic demo dataset.
        if not self.is_ready:
            self._bootstrap_demo_model()

        card = load_json(self.config.model_card_path)
        class_names = load_json(self.config.class_names_path)["class_names"]
        cls = get_backend_class(card["backend"])
        try:
            self._backend = cls.load(self.config.model_dir, class_names, tuple(card["image_size"]))
        except Exception as exc:
            logger.warning("Bundled model could not be loaded (%s); rebuilding locally.", exc)
            self._bootstrap_demo_model()
            card = load_json(self.config.model_card_path)
            class_names = load_json(self.config.class_names_path)["class_names"]
            self._backend = cls.load(self.config.model_dir, class_names, tuple(card["image_size"]))
        self._card, self._class_names = card, class_names

    def model_info(self) -> dict:
        if not self.is_ready:
            return {"model_ready": False}
        with self._lock:
            card = self._card or load_json(self.config.model_card_path)
        return {
            "model_ready": True,
            "backend": card["backend"],
            "trained_at": card["created_at"],
            "lunglens_version": card.get("lunglens_version"),
            "image_size": card["image_size"],
            "classes": [{"raw": n, "label": humanize_label(n)} for n in card["class_names"]],
            "dataset": card.get("dataset", {}),
            "evaluation": card.get("evaluation"),
            "cross_validation": card.get("cross_validation"),
            "disclaimer": DISCLAIMER,
        }

    def predict(self, image: Image.Image, explain: bool = False) -> dict:
        report = assess_image(image) if self.config.quality_check else None
        if report is not None and not report.ok:
            raise ImageQualityError(" ".join(report.reasons))

        with self._lock:
            self._load()
            size = tuple(self._card["image_size"])
            gray = to_gray_array(image, size, bool(self._card.get("normalize_contrast", True)))
            probs = self._backend.predict_proba(gray[None])[0]
            best = int(np.argmax(probs))
            heat_b64 = None
            if explain:
                heat = occlusion_heatmap(lambda batch: self._backend.predict_proba(batch)[:, best], gray,
                                         self.config.explain_grid)
                heat_b64 = overlay_png_base64(gray, heat)

        order = np.argsort(probs)[::-1]
        confidence = float(probs[best])
        margin = float(probs[order[0]] - probs[order[1]]) if len(order) > 1 else confidence
        reasons = []
        if confidence < self.config.confidence_threshold:
            reasons.append(f"top probability {confidence:.2f} is below {self.config.confidence_threshold:.2f}")
        if margin < self.config.min_margin:
            reasons.append(f"top two classes are close (margin {margin:.2f})")

        result = {
            "label": humanize_label(self._class_names[best]),
            "raw_label": self._class_names[best],
            "class_index": best,
            "confidence": round(confidence, 4),
            "margin": round(margin, 4),
            "entropy_bits": round(entropy(probs), 4),
            "uncertain": bool(reasons),
            "uncertain_reasons": reasons,
            "probabilities": [
                {"label": humanize_label(self._class_names[i]), "raw_label": self._class_names[i],
                 "probability": round(float(probs[i]), 4)} for i in order],
            "quality_warnings": report.warnings if report else [],
            "model": {"backend": self._card["backend"], "trained_at": self._card["created_at"]},
            "disclaimer": DISCLAIMER,
        }
        if heat_b64 is not None:
            result["explanation"] = {"method": "occlusion-sensitivity", "heatmap_png_base64": heat_b64}
        return result
