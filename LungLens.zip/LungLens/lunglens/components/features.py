"""Hand-crafted image features for the classic backend (sklearn-compatible transformer).

Per image (float32, [0,1], 2-D):
  intensity histogram + summary stats | HOG (shape/edges) | uniform LBP histograms (texture, global + grid)
  | GLCM texture statistics | small intensity thumbnail (coarse spatial layout)
"""
import numpy as np
from skimage.feature import graycomatrix, graycoprops, hog, local_binary_pattern
from skimage.transform import resize
from sklearn.base import BaseEstimator, TransformerMixin

_LBP_P, _LBP_R = 8, 1
_LBP_BINS = _LBP_P + 2  # 'uniform' LBP yields P+2 codes


class HandcraftedFeatures(BaseEstimator, TransformerMixin):
    def __init__(self, hog_cell=16, lbp_grid=2, hist_bins=32, thumb=16):
        self.hog_cell = hog_cell
        self.lbp_grid = lbp_grid
        self.hist_bins = hist_bins
        self.thumb = thumb

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.vstack([self._one(np.asarray(x, dtype=np.float32)) for x in X])

    # ---------------------------------------------------------------------------------------
    def _one(self, x: np.ndarray) -> np.ndarray:
        feats = [self._intensity(x), self._hog(x), self._lbp(x), self._glcm(x), self._thumbnail(x)]
        return np.nan_to_num(np.concatenate(feats).astype(np.float32))

    def _intensity(self, x):
        hist, _ = np.histogram(x, bins=self.hist_bins, range=(0.0, 1.0))
        stats = [x.mean(), x.std(), *np.percentile(x, [5, 25, 50, 75, 95])]
        return np.concatenate([hist / x.size, stats])

    def _hog(self, x):
        c = int(self.hog_cell)
        return hog(x, orientations=9, pixels_per_cell=(c, c), cells_per_block=(2, 2),
                   block_norm="L2-Hys", feature_vector=True)

    def _lbp(self, x):
        codes = local_binary_pattern((x * 255).astype(np.uint8), _LBP_P, _LBP_R, method="uniform")

        def hist(block):
            h, _ = np.histogram(block, bins=_LBP_BINS, range=(0, _LBP_BINS))
            return h / max(block.size, 1)

        out = [hist(codes)]
        g = int(self.lbp_grid)
        if g > 1:
            for rows in np.array_split(codes, g, axis=0):
                for cell in np.array_split(rows, g, axis=1):
                    out.append(hist(cell))
        return np.concatenate(out)

    def _glcm(self, x):
        q = np.clip((x * 15).round(), 0, 15).astype(np.uint8)  # 16 gray levels
        glcm = graycomatrix(q, distances=[1, 3], angles=[0, np.pi / 2], levels=16, symmetric=True, normed=True)
        props = ("contrast", "dissimilarity", "homogeneity", "energy", "correlation")
        return np.concatenate([graycoprops(glcm, p).ravel() for p in props])

    def _thumbnail(self, x):
        t = int(self.thumb)
        return resize(x, (t, t), anti_aliasing=True, preserve_range=True).ravel()
