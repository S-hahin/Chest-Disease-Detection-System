"""Model-agnostic explanation: occlusion sensitivity.

A gray patch is slid over the image; the drop in the predicted class' probability shows which regions
the model relied on. Works with every backend because it only needs ``predict_proba``.
Caveat: this shows what the *model* is sensitive to - not necessarily what is clinically relevant.
"""
import base64
import io
from typing import Callable

import numpy as np
from PIL import Image
from scipy import ndimage as ndi


def occlusion_heatmap(predict_target: Callable[[np.ndarray], np.ndarray], gray: np.ndarray, grid: int = 8) -> np.ndarray:
    """Return a (H, W) heatmap in [0, 1].

    ``predict_target`` maps a batch (N, H, W) to the probability of the class being explained, shape (N,).
    """
    h, w = gray.shape
    grid = max(2, int(grid))
    cy, cx = h / grid, w / grid
    fill = float(gray.mean())
    variants = []
    for i in range(grid):
        for j in range(grid):
            occluded = gray.copy()
            y0, y1 = int(max(0, (i - 0.5) * cy)), int(min(h, (i + 1.5) * cy))  # patch = 2 cells, stride = 1 cell
            x0, x1 = int(max(0, (j - 0.5) * cx)), int(min(w, (j + 1.5) * cx))
            occluded[y0:y1, x0:x1] = fill
            variants.append(occluded)
    base = float(predict_target(gray[None])[0])
    drops = base - np.asarray(predict_target(np.stack(variants)), dtype=np.float64)
    heat = np.clip(drops, 0, None).reshape(grid, grid)
    if heat.max() > 0:
        heat = heat / heat.max()
    return np.clip(ndi.zoom(heat, (h / grid, w / grid), order=1), 0, 1)[:h, :w]


def overlay_png_base64(gray: np.ndarray, heat: np.ndarray, alpha: float = 0.45, min_side: int = 256) -> str:
    """Blend the heatmap ('jet') over the grayscale image and return a base64-encoded PNG."""
    from matplotlib import colormaps

    rgb = colormaps["jet"](heat)[..., :3]
    base = np.repeat(gray[..., None], 3, axis=2)
    visible = np.clip((heat - 0.3) / 0.7, 0.0, 1.0)  # only colour clearly influential regions
    weight = alpha * visible[..., None]
    blended = np.clip(base * (1 - weight) + rgb * weight, 0, 1)
    img = Image.fromarray((blended * 255).astype(np.uint8))
    scale = max(1, min_side // max(img.size))
    if scale > 1:
        img = img.resize((img.width * scale, img.height * scale), Image.BILINEAR)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")
