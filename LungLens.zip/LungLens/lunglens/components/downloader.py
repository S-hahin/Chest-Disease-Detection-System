"""Dependency-free file downloader (replaces gdown).

* Standard library only (urllib) - nothing extra to install.
* Retries with exponential back-off on network errors / HTTP 429 / 5xx.
* Writes to ``<file>.part`` and renames on success, so an interrupted download never looks complete.
* Refuses HTML pages masquerading as files, and understands the Google Drive
  "large file - virus scan warning" confirmation page (best effort; Drive can change it at any time).
"""
import html
import http.cookiejar
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Optional

from lunglens.exception import DownloadError
from lunglens.logger import logger
from lunglens.utils import sha256_file

USER_AGENT = "Mozilla/5.0 (compatible; LungLens/2.0; +https://example.invalid)"
_DRIVE_ID = re.compile(r"drive\.google\.com/(?:file/d/|open\?id=|uc\?(?:[^#]*&)?id=)([\w-]+)")


def normalize_url(url: str) -> str:
    """Turn a Google Drive share link into a direct-download link; other URLs are returned unchanged."""
    m = _DRIVE_ID.search(url)
    if m:
        return f"https://drive.google.com/uc?export=download&id={m.group(1)}"
    return url


def _parse_drive_confirmation(page: str, base_url: str) -> Optional[str]:
    """Extract the real download URL from Google Drive's confirmation page, if that's what we got."""
    form = re.search(r'<form[^>]+id="download-form"[^>]+action="([^"]+)"', page)
    if form:
        action = html.unescape(form.group(1))
        fields = {
            html.unescape(n): html.unescape(v)
            for n, v in re.findall(r'<input[^>]+type="hidden"[^>]+name="([^"]+)"[^>]+value="([^"]*)"', page)
        }
        return action + ("&" if "?" in action else "?") + urllib.parse.urlencode(fields)
    link = re.search(r'href="(/uc\?export=download[^"]+)"', page)
    if link:
        return urllib.parse.urljoin(base_url, html.unescape(link.group(1)))
    return None


def _open(opener, url: str, timeout: int):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    return opener.open(req, timeout=timeout)


def _is_html(resp) -> bool:
    return "text/html" in (resp.headers.get("Content-Type") or "").lower()


def _download_once(url: str, part: Path, timeout: int) -> None:
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    resp = _open(opener, url, timeout)
    if _is_html(resp):
        page = resp.read(2_000_000).decode("utf-8", errors="replace")
        resp.close()
        confirm = _parse_drive_confirmation(page, url)
        if confirm is None:
            raise DownloadError(
                "The server returned a web page instead of a file (private/removed link, or the "
                "host is rate-limiting). Open the link in a browser, download the dataset manually "
                "and use `python main.py ingest --local <zip-or-folder>`."
            )
        resp = _open(opener, confirm, timeout)
        if _is_html(resp):
            resp.close()
            raise DownloadError("Google Drive kept returning a confirmation page; download the file manually.")

    total = int(resp.headers.get("Content-Length") or 0)
    done, last_log = 0, time.time()
    with open(part, "wb") as out:
        while True:
            block = resp.read(1 << 20)
            if not block:
                break
            out.write(block)
            done += len(block)
            if time.time() - last_log > 5:
                pct = f" ({done * 100 // total}%)" if total else ""
                logger.info("  downloaded %.1f MB%s", done / 1e6, pct)
                last_log = time.time()
    resp.close()
    if total and done != total:
        raise DownloadError(f"Incomplete download: got {done} of {total} bytes.")


def download_file(url: str, dest, retries: int = 3, timeout: int = 60,
                  expected_sha256: Optional[str] = None, backoff: float = 2.0) -> Path:
    """Download ``url`` to ``dest`` and return the path. Raises DownloadError on failure."""
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_name(dest.name + ".part")
    url = normalize_url(url)
    last_error: Optional[Exception] = None

    for attempt in range(1, max(1, retries) + 1):
        try:
            logger.info("Downloading %s (attempt %d/%d)", url, attempt, retries)
            _download_once(url, part, timeout)
            break
        except DownloadError:
            part.unlink(missing_ok=True)
            raise
        except urllib.error.HTTPError as e:
            last_error = e
            if e.code not in (429, 500, 502, 503, 504):  # permanent client error - don't retry
                part.unlink(missing_ok=True)
                raise DownloadError(f"HTTP {e.code} while downloading {url}") from e
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
            last_error = e
        if attempt < retries:
            wait = backoff ** attempt
            logger.warning("Download failed (%s); retrying in %.0fs", last_error, wait)
            time.sleep(wait)
    else:
        part.unlink(missing_ok=True)
        raise DownloadError(f"Download failed after {retries} attempts: {last_error}")

    if expected_sha256:
        actual = sha256_file(part)
        if actual.lower() != expected_sha256.lower():
            part.unlink(missing_ok=True)
            raise DownloadError(f"Checksum mismatch: expected {expected_sha256}, got {actual}.")
    part.replace(dest)
    logger.info("Saved %s (%.1f MB)", dest, dest.stat().st_size / 1e6)
    return dest
