from lunglens.components.backends.base import Backend
from lunglens.exception import ConfigError


def get_backend_class(name: str):
    """Look up a backend class by name. The Keras backend is imported lazily (TensorFlow is optional)."""
    name = str(name).lower()
    if name == "classic":
        from lunglens.components.backends.classic import ClassicBackend
        return ClassicBackend
    if name == "keras":
        from lunglens.components.backends.keras_backend import KerasBackend
        return KerasBackend
    raise ConfigError(f"Unknown backend '{name}'. Choose 'classic' or 'keras'.")


__all__ = ["Backend", "get_backend_class"]
