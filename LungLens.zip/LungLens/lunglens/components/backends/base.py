from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np


class Backend(ABC):
    """A trainable image classifier.

    Inputs are always float32 arrays of shape (N, H, W) with values in [0, 1] (grayscale CT slices).
    """

    name: str = "base"

    def __init__(self, class_names: List[str], image_size: Tuple[int, int], params: dict, seed: int = 42):
        self.class_names = list(class_names)
        self.image_size = (int(image_size[0]), int(image_size[1]))
        self.params = dict(params or {})
        self.seed = seed

    @abstractmethod
    def fit(self, x_train: np.ndarray, y_train: np.ndarray,
            x_val: Optional[np.ndarray] = None, y_val: Optional[np.ndarray] = None) -> dict:
        """Train and return a history dict of metric lists/values."""

    @abstractmethod
    def predict_proba(self, images: np.ndarray) -> np.ndarray:
        """Return class probabilities, shape (N, n_classes)."""

    @abstractmethod
    def save(self, model_dir: Path) -> None: ...

    @classmethod
    @abstractmethod
    def load(cls, model_dir: Path, class_names: List[str], image_size: Tuple[int, int]) -> "Backend": ...

    def cross_validate(self, x: np.ndarray, y: np.ndarray, folds: int) -> Optional[dict]:
        """Optional: k-fold CV summary. Backends for which this is too expensive return None."""
        return None
