"""Optional deep-learning backend: ImageNet transfer learning with Keras/TensorFlow.

Not installed by default (``pip install -r requirements-deep.txt``). Two phases:
1. train a new classification head on a frozen backbone, 2. fine-tune the top backbone layers.
NOTE: this module was written against the Keras 3 API but could not be executed in the environment
where LungLens 2.0 was assembled (no TensorFlow available) - see README "Verification status".
"""
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np

from lunglens.components.backends.base import Backend
from lunglens.components.dataset import class_weights
from lunglens.exception import ConfigError, LungLensError
from lunglens.logger import logger

_FILE = "model.keras"


def _import_keras():
    try:
        import keras  # noqa: F401
        import tensorflow as tf  # noqa: F401
        return keras, tf
    except ImportError as e:
        raise LungLensError(
            "The 'keras' backend needs TensorFlow: pip install -r requirements-deep.txt "
            "(or set BACKEND: classic in params.yaml)."
        ) from e


class KerasBackend(Backend):
    name = "keras"

    def __init__(self, class_names, image_size, params, seed=42, model=None):
        super().__init__(class_names, image_size, params, seed)
        self.model = model

    # ---- model ---------------------------------------------------------------------------
    def _build(self):
        keras, _ = _import_keras()
        from keras import layers

        p = self.params
        backbones = {
            "efficientnetb0": (keras.applications.EfficientNetB0, "identity"),
            "densenet121": (keras.applications.DenseNet121, "torch"),
            "resnet50v2": (keras.applications.ResNet50V2, "tf"),
        }
        name = str(p.get("BACKBONE", "efficientnetb0")).lower()
        if name not in backbones:
            raise ConfigError(f"keras.BACKBONE must be one of {list(backbones)}, got '{name}'.")
        ctor, style = backbones[name]
        shape = (*self.image_size, 3)
        base = ctor(include_top=False, weights=p.get("WEIGHTS", "imagenet"), input_shape=shape)
        base.trainable = False

        inputs = keras.Input(shape=shape, name="ct_slice")  # raw 0-255 RGB
        x = inputs
        if p.get("AUGMENTATION", True):
            # No horizontal flips: laterality (left/right lung) is part of the labels.
            x = keras.Sequential([layers.RandomRotation(0.04), layers.RandomTranslation(0.05, 0.05),
                                  layers.RandomZoom(0.1), layers.RandomContrast(0.1)], name="augmentation")(x)
        if style == "tf":
            x = layers.Rescaling(1.0 / 127.5, offset=-1.0)(x)
        elif style == "torch":
            x = layers.Rescaling(1.0 / 255.0)(x)
            x = layers.Normalization(mean=[0.485, 0.456, 0.406], variance=[0.229**2, 0.224**2, 0.225**2])(x)
        x = base(x, training=False)  # keep BatchNorm in inference mode, also while fine-tuning
        x = layers.GlobalAveragePooling2D()(x)
        x = layers.Dropout(float(p.get("DROPOUT", 0.3)))(x)
        outputs = layers.Dense(len(self.class_names), activation="softmax", name="predictions")(x)
        return keras.Model(inputs, outputs, name="lunglens"), base

    def _dataset(self, x, y, batch, shuffle):
        _, tf = _import_keras()
        n = len(self.class_names)
        ds = tf.data.Dataset.from_tensor_slices((x, y))
        if shuffle:
            ds = ds.shuffle(len(x), seed=self.seed)

        def to_rgb(img, label):
            return tf.repeat(img[..., None], 3, axis=-1) * 255.0, tf.one_hot(label, n)

        return ds.map(to_rgb, num_parallel_calls=tf.data.AUTOTUNE).batch(batch).prefetch(tf.data.AUTOTUNE)

    def _compile(self, lr):
        keras, _ = _import_keras()
        self.model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=lr),
            loss=keras.losses.CategoricalCrossentropy(label_smoothing=float(self.params.get("LABEL_SMOOTHING", 0.05))),
            metrics=["accuracy"])

    # ---- Backend API ---------------------------------------------------------------------
    def fit(self, x_train, y_train, x_val=None, y_val=None) -> dict:
        keras, _ = _import_keras()
        p = self.params
        keras.utils.set_random_seed(self.seed)
        self.model, base = self._build()
        batch = int(p.get("BATCH_SIZE", 16))
        train_ds = self._dataset(x_train, y_train, batch, True)
        val_ds = self._dataset(x_val, y_val, batch, False) if x_val is not None else None
        weights = class_weights(y_train, len(self.class_names))
        patience = int(p.get("PATIENCE", 5))
        callbacks = [
            keras.callbacks.EarlyStopping(monitor="val_loss", patience=patience, restore_best_weights=True),
            keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.3, patience=max(1, patience // 2), min_lr=1e-7),
        ] if val_ds is not None else []
        history: dict = {}

        def merge(h):
            for k, v in h.history.items():
                history.setdefault(k, []).extend(float(a) for a in v)

        if int(p.get("HEAD_EPOCHS", 10)) > 0:
            logger.info("Phase 1/2: training the classification head")
            self._compile(float(p.get("HEAD_LR", 1e-3)))
            merge(self.model.fit(train_ds, validation_data=val_ds, epochs=int(p.get("HEAD_EPOCHS", 10)),
                                 class_weight=weights, callbacks=callbacks))
        if int(p.get("FINETUNE_EPOCHS", 15)) > 0:
            n_layers = int(p.get("FINETUNE_LAYERS", 40))
            base.trainable = True
            frozen = base.layers[:-n_layers] if n_layers > 0 else base.layers
            for layer in frozen:
                layer.trainable = False
            for layer in base.layers:  # BatchNorm statistics stay frozen
                if isinstance(layer, keras.layers.BatchNormalization):
                    layer.trainable = False
            logger.info("Phase 2/2: fine-tuning the top %d backbone layers", n_layers)
            self._compile(float(p.get("FINETUNE_LR", 1e-5)))
            merge(self.model.fit(train_ds, validation_data=val_ds, epochs=int(p.get("FINETUNE_EPOCHS", 15)),
                                 class_weight=weights, callbacks=callbacks))
        return history

    def predict_proba(self, images) -> np.ndarray:
        _, tf = _import_keras()
        x = np.repeat(np.asarray(images, dtype=np.float32)[..., None], 3, axis=-1) * 255.0
        return np.asarray(self.model.predict(x, batch_size=32, verbose=0), dtype=np.float64)

    def save(self, model_dir: Path) -> None:
        Path(model_dir).mkdir(parents=True, exist_ok=True)
        self.model.save(Path(model_dir) / _FILE)

    @classmethod
    def load(cls, model_dir, class_names, image_size):
        keras, _ = _import_keras()
        return cls(class_names, image_size, {}, model=keras.models.load_model(Path(model_dir) / _FILE))
