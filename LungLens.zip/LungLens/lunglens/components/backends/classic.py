"""CPU-only backend: hand-crafted features + a scikit-learn classifier (no downloads, no GPU)."""
from pathlib import Path
from typing import List, Optional, Tuple

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from lunglens.components.backends.base import Backend
from lunglens.components.features import HandcraftedFeatures
from lunglens.exception import ConfigError
from lunglens.logger import logger

MODELS = ("ensemble", "svm", "logreg", "random_forest", "gradient_boosting")
_FILE = "classic_model.joblib"


def _classifier(kind: str, seed: int):
    def logreg():
        return LogisticRegression(C=0.5, max_iter=2000, class_weight="balanced", random_state=seed)

    def svm():
        return SVC(C=5.0, kernel="rbf", gamma="scale", probability=True, class_weight="balanced", random_state=seed)

    def rf():
        return RandomForestClassifier(n_estimators=300, class_weight="balanced", random_state=seed, n_jobs=-1)

    def gb():
        return HistGradientBoostingClassifier(max_iter=150, learning_rate=0.1, class_weight="balanced",
                                              random_state=seed)

    if kind == "logreg":
        return logreg()
    if kind == "svm":
        return svm()
    if kind == "random_forest":
        return rf()
    if kind == "gradient_boosting":
        return gb()
    if kind == "ensemble":
        return VotingClassifier([("logreg", logreg()), ("svm", svm()), ("gb", gb())], voting="soft")
    raise ConfigError(f"classic.MODEL must be one of {MODELS}, got '{kind}'.")


def build_pipeline(params: dict, seed: int) -> Pipeline:
    return Pipeline([
        ("features", HandcraftedFeatures(
            hog_cell=int(params.get("HOG_CELL", 16)), lbp_grid=int(params.get("LBP_GRID", 2)),
            hist_bins=int(params.get("HIST_BINS", 32)), thumb=int(params.get("THUMB", 16)))),
        ("scale", StandardScaler()),
        ("clf", _classifier(str(params.get("MODEL", "ensemble")).lower(), seed)),
    ])


class ClassicBackend(Backend):
    name = "classic"

    def __init__(self, class_names, image_size, params, seed=42, pipeline: Optional[Pipeline] = None):
        super().__init__(class_names, image_size, params, seed)
        self.pipeline = pipeline or build_pipeline(self.params, seed)

    def fit(self, x_train, y_train, x_val=None, y_val=None) -> dict:
        n_classes = len(self.class_names)
        if len(np.unique(y_train)) < n_classes:
            raise ConfigError("The training split is missing one or more classes.")
        logger.info("Fitting classic model '%s' on %d images", self.params.get("MODEL", "ensemble"), len(x_train))
        self.pipeline.fit(x_train, y_train)
        history = {"train_accuracy": float(accuracy_score(y_train, self.pipeline.predict(x_train)))}
        if x_val is not None:
            pred = self.pipeline.predict(x_val)
            history["val_accuracy"] = float(accuracy_score(y_val, pred))
            history["val_macro_f1"] = float(f1_score(y_val, pred, average="macro", zero_division=0))
        return history

    def predict_proba(self, images) -> np.ndarray:
        proba = self.pipeline.predict_proba(np.asarray(images, dtype=np.float32))
        full = np.zeros((len(proba), len(self.class_names)), dtype=np.float64)
        full[:, self.pipeline.classes_.astype(int)] = proba  # robust if a class was absent in training
        return full

    def cross_validate(self, x, y, folds):
        counts = np.bincount(y)
        folds = min(int(folds), int(counts[counts > 0].min()))
        if folds < 2:
            logger.warning("Too few images per class for cross-validation - skipped")
            return None
        cv = StratifiedKFold(n_splits=folds, shuffle=True, random_state=self.seed)
        scores = cross_val_score(build_pipeline(self.params, self.seed), x, y, cv=cv, scoring="accuracy")
        summary = {"folds": folds, "accuracy_mean": float(scores.mean()), "accuracy_std": float(scores.std()),
                   "accuracy_per_fold": [float(s) for s in scores]}
        logger.info("%d-fold CV accuracy: %.3f +/- %.3f", folds, summary["accuracy_mean"], summary["accuracy_std"])
        return summary

    def save(self, model_dir: Path) -> None:
        Path(model_dir).mkdir(parents=True, exist_ok=True)
        joblib.dump(self.pipeline, Path(model_dir) / _FILE, compress=3)

    @classmethod
    def load(cls, model_dir, class_names, image_size):
        path = Path(model_dir) / _FILE
        # joblib uses pickle: only load model files you trained yourself or otherwise trust.
        return cls(class_names, image_size, {}, pipeline=joblib.load(path))
