"""Cheap input sanity checks so obviously wrong uploads are rejected instead of getting a confident label."""
from dataclasses import dataclass, field
from typing import List

import numpy as np
from PIL import Image

MIN_SIDE = 64


@dataclass
class QualityReport:
    reasons: List[str] = field(default_factory=list)   # reasons to reject the image
    warnings: List[str] = field(default_factory=list)  # soft issues, image still classified

    @property
    def ok(self) -> bool:
        return not self.reasons


def assess_image(im: Image.Image) -> QualityReport:
    report = QualityReport()
    w, h = im.size
    if min(w, h) < MIN_SIDE:
        report.reasons.append(f"Image is too small ({w}x{h}px); at least {MIN_SIDE}px per side is required.")
        return report

    thumb = im.copy()
    thumb.thumbnail((256, 256))
    if thumb.mode in ("I", "F") or thumb.mode.startswith("I;"):
        a = np.asarray(thumb, dtype=np.float64)
        rng = a.max() - a.min()
        gray = (a - a.min()) / rng if rng > 0 else np.zeros_like(a)
        rgb = None
    else:
        rgb = np.asarray(thumb.convert("RGB"), dtype=np.float64)
        gray = rgb.mean(axis=2) / 255.0

    if gray.std() < 0.02:
        report.reasons.append("Image is blank or almost uniform - it does not look like a CT slice.")
    if rgb is not None:
        colourfulness = float(np.mean(np.abs(rgb[..., 0] - rgb[..., 1]) + np.abs(rgb[..., 1] - rgb[..., 2])) / 2)
        if colourfulness > 25:
            report.reasons.append("Image is a colour photograph/graphic; CT slices are grayscale.")
    if not report.reasons:
        ratio = w / h
        if ratio < 0.5 or ratio > 2.0:
            report.warnings.append("Unusual aspect ratio; the image will be squashed to a square before analysis.")
        if gray.mean() > 0.8:
            report.warnings.append("Image is very bright - is this a CT slice with a standard window?")
        elif gray.mean() < 0.05:
            report.warnings.append("Image is very dark.")
    return report
