"""Image preprocessing shared by training and inference (so both see identical inputs)."""
from typing import Tuple

import numpy as np
from PIL import Image, ImageOps


def _to_8bit_gray(im: Image.Image) -> Image.Image:
    """Convert any PIL image to 8-bit grayscale. 16-bit / float scans (e.g. DICOM exports) are min-max scaled."""
    im = ImageOps.exif_transpose(im)
    if im.mode in ("L",):
        return im
    if im.mode.startswith("I") or im.mode == "F":
        arr = np.asarray(im, dtype=np.float64)
        lo, hi = float(arr.min()), float(arr.max())
        scaled = np.zeros_like(arr) if hi <= lo else (arr - lo) / (hi - lo)
        return Image.fromarray((scaled * 255).astype(np.uint8), mode="L")
    if im.mode in ("RGBA", "LA", "P"):
        im = im.convert("RGBA")
        background = Image.new("RGBA", im.size, (0, 0, 0, 255))  # transparent areas -> black (air)
        im = Image.alpha_composite(background, im)
    return im.convert("L")


def stretch_contrast(arr: np.ndarray, low: float = 1.0, high: float = 99.0) -> np.ndarray:
    """Percentile contrast stretch to [0, 1]; robust to a few hot/dead pixels and to exposure differences."""
    lo, hi = np.percentile(arr, [low, high])
    if hi - lo < 1e-6:
        return arr
    return np.clip((arr - lo) / (hi - lo), 0.0, 1.0).astype(np.float32)


def to_gray_array(im: Image.Image, size: Tuple[int, int], normalize_contrast: bool = True) -> np.ndarray:
    """PIL image -> float32 array (H, W) in [0, 1], resized to ``size`` = (height, width)."""
    gray = _to_8bit_gray(im).resize((int(size[1]), int(size[0])), Image.BILINEAR)
    arr = np.asarray(gray, dtype=np.float32) / 255.0
    return stretch_contrast(arr) if normalize_contrast else arr
