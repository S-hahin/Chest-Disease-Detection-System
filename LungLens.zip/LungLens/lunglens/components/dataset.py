"""Framework-free dataset discovery, splitting and loading.

Supported layouts (auto-detected):

1. Pre-split:  root/train/<class>/*.jpg, root/valid/<class>/*.jpg [, root/test/<class>/*.jpg]
               (class folders in valid/test may use a short name, e.g. 'adenocarcinoma' for
               'adenocarcinoma_left.lower.lobe_T2_N0_M0_Ib' - they are matched automatically)
2. Flat:       root/<class>/*.jpg  -> stratified train/valid/test split using the configured fractions
"""
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from PIL import Image
from sklearn.model_selection import train_test_split

from lunglens.components.preprocessing import to_gray_array
from lunglens.constants import IMAGE_EXTENSIONS
from lunglens.exception import DatasetError
from lunglens.logger import logger

TRAIN_NAMES = ("train", "training")
VALID_NAMES = ("valid", "val", "validation")
TEST_NAMES = ("test", "testing")
SPLIT_NAMES = set(TRAIN_NAMES + VALID_NAMES + TEST_NAMES)

Item = Tuple[Path, int]


@dataclass
class DatasetIndex:
    root: Path
    layout: str                       # "pre-split" | "flat"
    class_names: List[str]
    train: List[Item] = field(default_factory=list)
    val: List[Item] = field(default_factory=list)
    test: List[Item] = field(default_factory=list)

    @property
    def eval_split(self) -> Tuple[str, List[Item]]:
        """The split used for final evaluation: test if present, else validation."""
        return ("test", self.test) if self.test else ("validation", self.val)


def _ignored(p) -> bool:
    name = p if isinstance(p, str) else p.name
    return name.startswith((".", "_"))  # .git, __MACOSX, ...


def _images_in(folder: Path) -> List[Path]:
    return sorted(p for p in folder.iterdir()
                  if p.is_file() and not p.name.startswith(".") and p.suffix.lower() in IMAGE_EXTENSIONS)


def _class_dirs(folder: Path) -> List[Path]:
    return [d for d in sorted(folder.iterdir()) if d.is_dir() and not _ignored(d) and _images_in(d)]


def find_dataset_root(base) -> Optional[Path]:
    """Return the folder that holds the class folders, or the train/valid/test split folders."""
    base = Path(base)
    if not base.exists():
        return None
    subdirs = sorted((d for d in base.rglob("*") if d.is_dir() and not any(_ignored(x) for x in d.relative_to(base).parts)),
                     key=lambda d: (len(d.parts), str(d)))
    for d in [base] + subdirs:
        if len(_class_dirs(d)) >= 2:
            # class folders found; if they sit inside train/valid/test, the dataset root is one level up
            return d.parent if d.name.lower() in SPLIT_NAMES else d
    return None


def _pick(root: Path, names) -> Optional[Path]:
    for n in names:
        for d in root.iterdir():
            if d.is_dir() and d.name.lower() == n:
                return d
    return None


def match_class(name: str, class_names: Sequence[str]) -> Optional[int]:
    """Match a class folder from valid/test to the training classes (exact, then by name prefix)."""
    if name in class_names:
        return class_names.index(name)
    key = name.split("_")[0].lower()
    hits = [i for i, c in enumerate(class_names) if c.split("_")[0].lower() == key]
    return hits[0] if len(hits) == 1 else None


def _items_for_split(folder: Path, class_names: List[str], label: str) -> List[Item]:
    items: List[Item] = []
    for d in _class_dirs(folder):
        idx = match_class(d.name, class_names)
        if idx is None:
            logger.warning("%s: class folder '%s' has no match among training classes - ignored", label, d.name)
            continue
        items.extend((p, idx) for p in _images_in(d))
    return items


def build_index(data_dir, validation_split: float, test_split: float, seed: int) -> DatasetIndex:
    root = find_dataset_root(data_dir)
    if root is None:
        raise DatasetError(
            f"No image dataset found under '{data_dir}'. Expected class folders containing images "
            "(e.g. data/<name>/<class>/*.jpg). Get data with one of:\n"
            "  python main.py ingest --local path/to/dataset.zip   (or an already-extracted folder)\n"
            "  python main.py ingest                                (download from the URL in config.yaml)\n"
            "  python main.py ingest --synthetic                    (generate a demo dataset)"
        )
    train_dir, val_dir, test_dir = _pick(root, TRAIN_NAMES), _pick(root, VALID_NAMES), _pick(root, TEST_NAMES)

    if train_dir is not None and val_dir is not None:
        class_names = [d.name for d in _class_dirs(train_dir)]
        index = DatasetIndex(root, "pre-split", class_names)
        index.train = _items_for_split(train_dir, class_names, "train")
        index.val = _items_for_split(val_dir, class_names, "valid")
        if test_dir is not None:
            index.test = _items_for_split(test_dir, class_names, "test")
    else:
        class_dirs = _class_dirs(root)
        class_names = [d.name for d in class_dirs]
        items = [(p, i) for i, d in enumerate(class_dirs) for p in _images_in(d)]
        counts = np.bincount([y for _, y in items], minlength=len(class_names))
        if counts.min() < 4:
            small = [class_names[i] for i in np.where(counts < 4)[0]]
            raise DatasetError(f"Each class needs at least 4 images for a train/valid/test split; too few in: {small}")
        index = DatasetIndex(root, "flat", class_names)
        labels = np.array([y for _, y in items])
        ids = np.arange(len(items))
        try:
            rest, test_ids = (ids, np.array([], dtype=int))
            if test_split > 0:
                rest, test_ids = train_test_split(ids, test_size=test_split, stratify=labels, random_state=seed)
            val_frac = validation_split / (1.0 - test_split)
            train_ids, val_ids = train_test_split(rest, test_size=val_frac, stratify=labels[rest], random_state=seed)
        except ValueError as e:
            raise DatasetError(f"Dataset too small for the requested splits ({e}). "
                               "Add images or lower VALIDATION_SPLIT/TEST_SPLIT.") from e
        index.train = [items[i] for i in sorted(train_ids)]
        index.val = [items[i] for i in sorted(val_ids)]
        index.test = [items[i] for i in sorted(test_ids)]

    if len(class_names) < 2:
        raise DatasetError("At least two classes are required for classification.")
    if not index.train or not index.val:
        raise DatasetError("Training and validation splits must both contain images.")
    overlap = {p for p, _ in index.train} & {p for p, _ in index.val + index.test}
    if overlap:  # can only happen with a malformed dataset; leaking test data would fake good scores
        raise DatasetError(f"{len(overlap)} files appear in both the training and evaluation splits.")
    logger.info("Dataset '%s' (%s): %d classes | train=%d valid=%d test=%d",
                index.root.name, index.layout, len(class_names), len(index.train), len(index.val), len(index.test))
    return index


def class_weights(labels: Sequence[int], n_classes: int) -> Dict[int, float]:
    """Balanced weights: n_samples / (n_classes * n_samples_of_class)."""
    counts = np.maximum(np.bincount(np.asarray(labels, dtype=int), minlength=n_classes), 1)
    return {i: float(counts.sum() / (n_classes * c)) for i, c in enumerate(counts)}


def load_split(items: Sequence[Item], size: Tuple[int, int], normalize_contrast: bool = True):
    """Load images as float32 (N, H, W) in [0, 1] plus int labels. Unreadable files are skipped."""
    xs, ys, skipped = [], [], 0
    for path, label in items:
        try:
            with Image.open(path) as im:
                xs.append(to_gray_array(im, size, normalize_contrast))
            ys.append(label)
        except Exception as e:  # corrupt/truncated image
            skipped += 1
            logger.warning("Skipping unreadable image %s (%s)", path, e)
    if not xs:
        raise DatasetError("None of the images in this split could be read.")
    if skipped:
        logger.warning("%d unreadable image(s) skipped", skipped)
    return np.stack(xs).astype(np.float32), np.asarray(ys, dtype=np.int64)
