"""Get a dataset onto disk from: an existing folder, a local zip, a URL (incl. Google Drive), or synthetic data."""
import shutil
import zipfile
from pathlib import Path
from typing import Optional

from lunglens.components.dataset import find_dataset_root
from lunglens.components.downloader import download_file
from lunglens.components.synthetic import generate_dataset
from lunglens.config.entity import DataIngestionConfig
from lunglens.exception import DatasetError, DownloadError
from lunglens.logger import logger


def safe_extract(zip_path, dest) -> int:
    """Extract a zip while refusing path-traversal ('zip slip') entries and macOS metadata."""
    dest = Path(dest).resolve()
    dest.mkdir(parents=True, exist_ok=True)
    n = 0
    with zipfile.ZipFile(zip_path) as zf:
        for member in zf.infolist():
            name = member.filename
            if name.startswith("__MACOSX/") or "/__MACOSX/" in name:
                continue
            target = (dest / name).resolve()
            if dest != target and dest not in target.parents:
                raise DatasetError(f"Unsafe path in zip archive: '{name}'")
            zf.extract(member, dest)
            n += 0 if member.is_dir() else 1
    return n


class DataIngestion:
    def __init__(self, config: DataIngestionConfig):
        self.config = config

    def _extract(self, archive: Path) -> None:
        if not zipfile.is_zipfile(archive):
            raise DatasetError(f"'{archive}' is not a valid zip archive.")
        count = safe_extract(archive, self.config.data_dir)
        logger.info("Extracted %d files from %s -> %s", count, archive, self.config.data_dir)

    def from_local(self, source) -> None:
        source = Path(source).expanduser()
        if not source.exists():
            raise DatasetError(f"Local source not found: {source}")
        if source.is_dir():
            if find_dataset_root(source) is None:
                raise DatasetError(f"No class folders with images found in {source}.")
            target = self.config.data_dir / source.name
            if source.resolve() != target.resolve():
                shutil.copytree(source, target, dirs_exist_ok=True)
                logger.info("Copied %s -> %s", source, target)
        else:
            self._extract(source)

    def from_url(self, url: Optional[str] = None) -> None:
        url = url or self.config.source_url
        if not url:
            raise DatasetError("No download URL configured (data_ingestion.source_url in config/config.yaml).")
        archive = self.config.archive_path
        if not (archive.exists() and archive.stat().st_size > 0):
            try:
                download_file(url, archive, retries=self.config.download_retries,
                              timeout=self.config.download_timeout,
                              expected_sha256=self.config.archive_sha256)
            except DownloadError as e:
                raise DatasetError(
                    f"{e}\nFallbacks: `python main.py ingest --local <zip-or-folder>` with a manually "
                    "downloaded dataset, or `python main.py ingest --synthetic` for a demo dataset."
                ) from e
        try:
            self._extract(archive)
        except (DatasetError, zipfile.BadZipFile) as e:
            archive.unlink(missing_ok=True)  # do not keep a corrupt archive around
            raise DatasetError(f"Downloaded file is not a usable zip ({e}). It was deleted; try again.") from e

    def synthetic(self, per_class: int = 60, seed: int = 0, size: int = 128) -> None:
        out = self.config.data_dir / "synthetic_ct"
        counts = generate_dataset(out, per_class=per_class, size=size, seed=seed, presplit=True)
        logger.info("Generated synthetic dataset at %s: %s", out, counts)

    def run(self, local: Optional[str] = None, url: Optional[str] = None,
            synthetic: bool = False, per_class: int = 60, force: bool = False) -> Path:
        if not force:
            existing = find_dataset_root(self.config.data_dir)
            if existing is not None:
                logger.info("Dataset already present at %s - nothing to do (use --force to re-ingest).", existing)
                return existing
        if synthetic:
            self.synthetic(per_class=per_class)
        elif local:
            self.from_local(local)
        else:
            self.from_url(url)
        root = find_dataset_root(self.config.data_dir)
        if root is None:
            raise DatasetError("Ingestion finished but no class folders with images were found.")
        return root
