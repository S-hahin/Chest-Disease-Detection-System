"""Synthetic chest-CT-like image generator.

Purpose: let anyone run and test the *whole* pipeline offline in a minute. The images are
cartoonish (two lung fields inside a body outline) with class-specific findings:

* normal                    - clean lungs
* adenocarcinoma            - a small, soft, peripheral nodule
* large.cell.carcinoma      - a large dense mass
* squamous.cell.carcinoma   - a ring-shaped (cavitating) lesion near the central hilum

They are NOT medical images. Accuracy on them says nothing about real-world performance.
"""
from pathlib import Path
from typing import Dict, Sequence

import numpy as np
from PIL import Image
from scipy import ndimage as ndi

DEFAULT_CLASSES = (
    "adenocarcinoma_left.lower.lobe_T2_N0_M0_Ib",
    "large.cell.carcinoma_left.hilum_T2_N2_M0_IIIa",
    "normal",
    "squamous.cell.carcinoma_left.hilum_T1_N2_M0_IIIa",
)


def _kind(class_name: str) -> str:
    n = class_name.lower()
    for key in ("adenocarcinoma", "large", "squamous", "normal"):
        if n.startswith(key):
            return key
    return "normal"


def _blob(shape, cy, cx, ry, rx):
    yy, xx = np.ogrid[: shape[0], : shape[1]]
    return (((yy - cy) / ry) ** 2 + ((xx - cx) / rx) ** 2 <= 1.0).astype(np.float32)


def make_ct_slice(kind: str, rng: np.random.Generator, size: int = 128) -> np.ndarray:
    """Return a uint8 (size, size) synthetic slice for ``kind``."""
    s = (size, size)
    img = np.zeros(s, dtype=np.float32)
    body = _blob(s, size * 0.5, size * 0.5, size * 0.44, size * 0.46)
    img += 0.35 * body                                     # soft tissue
    jitter = rng.uniform(-0.03, 0.03) * size
    left = _blob(s, size * 0.5 + jitter, size * 0.3, size * 0.30, size * 0.15)
    right = _blob(s, size * 0.5 + jitter, size * 0.7, size * 0.30, size * 0.15)
    lungs = np.clip(left + right, 0, 1)
    img = img * (1 - lungs) + 0.08 * lungs                 # air-filled lungs are dark
    img += 0.55 * _blob(s, size * 0.72, size * 0.5, size * 0.05, size * 0.04)  # spine

    lesion = np.zeros(s, dtype=np.float32)
    side = rng.choice([0.3, 0.7])                          # which lung the finding is in
    if kind == "adenocarcinoma":
        cx = side + (0.09 if side < 0.5 else -0.09) * rng.uniform(0.6, 1.0)
        lesion = _blob(s, size * rng.uniform(0.35, 0.62), size * cx, size * rng.uniform(0.035, 0.05),
                       size * rng.uniform(0.035, 0.05)) * 0.45
    elif kind == "large":
        lesion = _blob(s, size * rng.uniform(0.38, 0.6), size * side, size * rng.uniform(0.11, 0.15),
                       size * rng.uniform(0.09, 0.12)) * 0.75
    elif kind == "squamous":
        cx = 0.5 + (-0.12 if side < 0.5 else 0.12)         # near the mediastinum / hilum
        cy = size * rng.uniform(0.42, 0.55)
        outer = _blob(s, cy, size * cx, size * 0.075, size * 0.07)
        inner = _blob(s, cy, size * cx, size * 0.035, size * 0.03)
        lesion = np.clip(outer - inner, 0, 1) * 0.7
    img = np.maximum(img, lesion * (lungs + 0.3 * body))
    img = ndi.gaussian_filter(img, sigma=size / 128 * 1.2)
    img += rng.normal(0, 0.03, s) + rng.uniform(-0.04, 0.04)   # scanner noise / brightness drift
    return (np.clip(img, 0, 1) * 255).astype(np.uint8)


def generate_dataset(out_dir, per_class: int = 60, classes: Sequence[str] = DEFAULT_CLASSES,
                     size: int = 128, seed: int = 0, presplit: bool = True) -> Dict[str, int]:
    """Write a dataset under ``out_dir``.

    presplit=True  -> out_dir/{train,valid,test}/<class>/*.png  (70/15/15)
    presplit=False -> out_dir/<class>/*.png
    Returns image counts per split.
    """
    out_dir = Path(out_dir)
    rng = np.random.default_rng(seed)
    counts: Dict[str, int] = {}
    if presplit:
        n_valid = max(2, round(per_class * 0.15))
        n_test = max(2, round(per_class * 0.15))
        plan = {"train": per_class - n_valid - n_test, "valid": n_valid, "test": n_test}
    else:
        plan = {"": per_class}
    for split, n in plan.items():
        for cls in classes:
            folder = out_dir / split / cls if split else out_dir / cls
            folder.mkdir(parents=True, exist_ok=True)
            for i in range(n):
                Image.fromarray(make_ct_slice(_kind(cls), rng, size)).save(folder / f"{i:04d}.png")
        counts[split or "all"] = n * len(classes)
    return counts
