import platform
import sys
from datetime import datetime, timezone

import numpy as np
import sklearn

from lunglens import __version__
from lunglens.components.backends import get_backend_class
from lunglens.components.dataset import build_index, load_split
from lunglens.config.entity import TrainingConfig
from lunglens.logger import logger
from lunglens.utils import fingerprint, save_json


class Trainer:
    """Loads the dataset, trains the configured backend, and writes the model bundle + model card."""

    def __init__(self, config: TrainingConfig):
        self.config = config

    def run(self) -> dict:
        c = self.config
        index = build_index(c.data_dir, c.validation_split, c.test_split, c.seed)
        x_train, y_train = load_split(index.train, c.image_size, c.normalize_contrast)
        x_val, y_val = load_split(index.val, c.image_size, c.normalize_contrast)

        backend = get_backend_class(c.backend)(index.class_names, c.image_size, c.backend_params, c.seed)

        cv = None
        if c.cv_folds >= 2:
            cv = backend.cross_validate(x_train, y_train, c.cv_folds)

        history = backend.fit(x_train, y_train, x_val, y_val)

        backend.save(c.model_dir)
        save_json(c.class_names_path, {"class_names": index.class_names})
        save_json(c.history_path, history)

        card = {
            "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "lunglens_version": __version__,
            "backend": c.backend,
            "backend_params": c.backend_params,
            "image_size": list(c.image_size),
            "normalize_contrast": c.normalize_contrast,
            "class_names": index.class_names,
            "dataset": {
                "layout": index.layout,
                "train_images": len(y_train),
                "validation_images": len(y_val),
                "test_images": len(index.test),
                "class_counts_train": {n: int((y_train == i).sum()) for i, n in enumerate(index.class_names)},
                "train_fingerprint": fingerprint(f"{p.name}:{y}" for p, y in index.train),
            },
            "split": {"validation_split": c.validation_split, "test_split": c.test_split, "seed": c.seed},
            "training": {k: (v[-1] if isinstance(v, list) else v) for k, v in history.items()},
            "cross_validation": cv,
            "environment": {"python": sys.version.split()[0], "platform": platform.platform(),
                            "numpy": np.__version__, "scikit_learn": sklearn.__version__},
        }
        save_json(c.model_card_path, card)
        logger.info("Model saved to %s (val metrics: %s)", c.model_dir, card["training"])
        return card
