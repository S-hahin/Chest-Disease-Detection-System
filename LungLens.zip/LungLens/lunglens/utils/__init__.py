import base64
import hashlib
import json
import re
from pathlib import Path

import yaml

from lunglens.exception import ConfigError


def read_yaml(path) -> dict:
    try:
        with open(path, encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except (OSError, yaml.YAMLError) as e:
        raise ConfigError(f"Cannot read YAML file '{path}': {e}") from e
    if not isinstance(data, dict):
        raise ConfigError(f"'{path}' must contain a YAML mapping.")
    return data


def save_json(path, data) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=False)


def load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def sha256_file(path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def fingerprint(items) -> str:
    """Stable short hash of an iterable of strings (used to detect changed datasets)."""
    h = hashlib.sha256()
    for s in sorted(items):
        h.update(s.encode("utf-8"))
        h.update(b"\0")
    return h.hexdigest()[:16]


def decode_image_bytes(b64_string: str) -> bytes:
    """Decode a base64 string (optionally a data-URL) into raw bytes."""
    if b64_string.startswith("data:") and "," in b64_string:
        b64_string = b64_string.split(",", 1)[1]
    return base64.b64decode(b64_string, validate=False)


_STAGING = re.compile(r"^([TNM][0-9xX]+|I{1,3}[ab]?|IV[ab]?)$")


def humanize_label(raw: str) -> str:
    """Turn a dataset folder name into a readable label.

    'adenocarcinoma_left.lower.lobe_T2_N0_M0_Ib'
        -> 'Adenocarcinoma (left lower lobe, T2 N0 M0 Ib)'
    'normal' -> 'Normal'
    """
    parts = raw.split("_")
    name = parts[0].replace(".", " ").strip().capitalize()
    details, staging = [], []
    for p in parts[1:]:
        (staging if _STAGING.match(p) else details).append(p.replace(".", " "))
    extra = details + ([" ".join(staging)] if staging else [])
    return f"{name} ({', '.join(extra)})" if extra else name
