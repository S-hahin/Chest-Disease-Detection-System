"""LungLens - chest CT slice classification (classic ML + optional deep learning)."""

__version__ = "2.0.0"
