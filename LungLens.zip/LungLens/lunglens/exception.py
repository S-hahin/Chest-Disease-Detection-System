class LungLensError(Exception):
    """Base class for all project errors (message is always user-presentable)."""


class DatasetError(LungLensError):
    """Dataset missing, malformed or too small."""


class DownloadError(LungLensError):
    """A dataset download failed."""


class ModelNotReadyError(LungLensError):
    """Inference requested before a model has been trained."""


class ImageQualityError(LungLensError):
    """The uploaded image is unsuitable for classification (blank, colour photo, tiny...)."""


class ConfigError(LungLensError):
    """config.yaml / params.yaml contain an invalid value."""
