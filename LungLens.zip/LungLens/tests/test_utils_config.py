import base64
import os
import unittest
from unittest import mock

from lunglens.config.configuration import ConfigurationManager
from lunglens.constants import CONFIG_FILE_PATH, PARAMS_FILE_PATH
from lunglens.exception import ConfigError
from lunglens.utils import decode_image_bytes, fingerprint, humanize_label, read_yaml
from tests.helpers import tmpdir


class UtilsTests(unittest.TestCase):
    def test_humanize(self):
        self.assertEqual(humanize_label("normal"), "Normal")
        self.assertEqual(humanize_label("adenocarcinoma_left.lower.lobe_T2_N0_M0_Ib"),
                         "Adenocarcinoma (left lower lobe, T2 N0 M0 Ib)")
        self.assertEqual(humanize_label("large.cell.carcinoma"), "Large cell carcinoma")

    def test_decode_data_url(self):
        url = "data:image/jpeg;base64," + base64.b64encode(b"hello").decode()
        self.assertEqual(decode_image_bytes(url), b"hello")

    def test_fingerprint_is_order_independent(self):
        self.assertEqual(fingerprint(["a", "b"]), fingerprint(["b", "a"]))
        self.assertNotEqual(fingerprint(["a", "b"]), fingerprint(["a", "c"]))

    def test_read_yaml_errors_are_project_errors(self):
        with self.assertRaises(ConfigError):
            read_yaml(tmpdir() / "missing.yaml")


class ConfigTests(unittest.TestCase):
    def make(self, **overrides):
        return ConfigurationManager(CONFIG_FILE_PATH, PARAMS_FILE_PATH, root=tmpdir(), param_overrides=overrides)

    def test_defaults_load(self):
        m = self.make()
        self.assertEqual(m.get_training_config().backend, "classic")
        self.assertEqual(m.get_training_config().image_size, (128, 128))

    def test_invalid_values_rejected(self):
        for bad in ({"BACKEND": "svm"}, {"IMAGE_SIZE": [8, 8]}, {"IMAGE_SIZE": 128},
                    {"VALIDATION_SPLIT": 0.9}, {"TEST_SPLIT": 0.7}, {"CV_FOLDS": 1}, {"CONFIDENCE_THRESHOLD": 3}):
            with self.subTest(bad=bad), self.assertRaises(ConfigError):
                self.make(**bad)

    def test_home_env_var_moves_the_workspace(self):
        home = tmpdir()
        with mock.patch.dict(os.environ, {"LUNGLENS_HOME": str(home)}):
            m = ConfigurationManager()
        self.assertEqual(m.get_training_config().model_dir, home.resolve() / "artifacts" / "model")


if __name__ == "__main__":
    unittest.main()
