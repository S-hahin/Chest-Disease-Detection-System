import importlib.util
import unittest

import numpy as np

from lunglens.components.backends import get_backend_class
from lunglens.exception import ConfigError, LungLensError

HAS_TF = importlib.util.find_spec("tensorflow") is not None


class BackendRegistryTests(unittest.TestCase):
    def test_unknown_backend(self):
        with self.assertRaises(ConfigError):
            get_backend_class("nope")

    @unittest.skipIf(HAS_TF, "TensorFlow is installed")
    def test_keras_without_tensorflow_gives_install_hint(self):
        backend = get_backend_class("keras")([ "a", "b"], (32, 32), {})
        with self.assertRaisesRegex(LungLensError, "requirements-deep.txt"):
            backend.fit(np.zeros((2, 32, 32), np.float32), np.array([0, 1]))


@unittest.skipUnless(HAS_TF, "TensorFlow not installed - install requirements-deep.txt to run this test")
class KerasBackendTests(unittest.TestCase):
    def test_fit_predict_save_load_roundtrip(self):
        import tempfile
        from pathlib import Path
        rng = np.random.default_rng(0)
        x = rng.uniform(0, 1, (24, 64, 64)).astype(np.float32)
        y = np.array([0, 1, 2] * 8)
        params = {"BACKBONE": "resnet50v2", "WEIGHTS": None, "BATCH_SIZE": 8, "HEAD_EPOCHS": 1,
                  "FINETUNE_EPOCHS": 1, "FINETUNE_LAYERS": 5, "AUGMENTATION": False}
        b = get_backend_class("keras")(["a", "b", "c"], (64, 64), params)
        b.fit(x, y, x[:6], y[:6])
        proba = b.predict_proba(x[:4])
        self.assertEqual(proba.shape, (4, 3))
        np.testing.assert_allclose(proba.sum(axis=1), 1.0, atol=1e-4)
        with tempfile.TemporaryDirectory() as d:
            b.save(Path(d))
            loaded = get_backend_class("keras").load(Path(d), ["a", "b", "c"], (64, 64))
            np.testing.assert_allclose(loaded.predict_proba(x[:4]), proba, atol=1e-4)


if __name__ == "__main__":
    unittest.main()
