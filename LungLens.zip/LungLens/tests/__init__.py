import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("LUNGLENS_LOG_LEVEL", "WARNING")
os.environ.setdefault("LUNGLENS_LOG_DIR", str(Path(tempfile.gettempdir()) / "lunglens-test-logs"))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
