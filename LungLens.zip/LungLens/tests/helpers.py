"""Shared test utilities (all tests run offline)."""
import atexit
import functools
import http.server
import shutil
import tempfile
import threading
import zipfile
from pathlib import Path

from lunglens.components.synthetic import generate_dataset
from lunglens.config.configuration import ConfigurationManager
from lunglens.constants import CONFIG_FILE_PATH, PARAMS_FILE_PATH

FAST = {"CV_FOLDS": 0, "classic": {"MODEL": "logreg"}}


def tmpdir() -> Path:
    d = Path(tempfile.mkdtemp(prefix="lunglens-test-"))
    atexit.register(shutil.rmtree, d, ignore_errors=True)
    return d


def manager(root: Path, **overrides) -> ConfigurationManager:
    params = {**FAST, **overrides}
    return ConfigurationManager(CONFIG_FILE_PATH, PARAMS_FILE_PATH, root=root, param_overrides=params)


_TRAINED = {}


def trained_workspace():
    """A workspace with a synthetic dataset and a trained + evaluated model (built once per test run)."""
    if "m" not in _TRAINED:
        from lunglens.pipeline import evaluate, train
        root = tmpdir()
        m = manager(root, CV_FOLDS=2)
        generate_dataset(root / "data" / "synthetic_ct", per_class=24, seed=3)
        train.main(m)
        evaluate.main(m)
        _TRAINED["m"] = m
    return _TRAINED["m"]


def zip_dir(src: Path, dest: Path) -> Path:
    with zipfile.ZipFile(dest, "w") as zf:
        for p in sorted(src.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(src.parent))
    return dest


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


class LocalServer:
    """Serve a directory on 127.0.0.1 (random port) in a background thread."""

    def __init__(self, directory: Path, handler=QuietHandler):
        self.httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(handler, directory=str(directory)))
        self.port = self.httpd.server_address[1]

    def url(self, name: str) -> str:
        return f"http://127.0.0.1:{self.port}/{name}"

    def __enter__(self):
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        return self

    def __exit__(self, *exc):
        self.httpd.shutdown()
        self.httpd.server_close()
