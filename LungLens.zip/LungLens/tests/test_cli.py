import contextlib
import io
import os
import unittest
from unittest import mock

import numpy as np
from PIL import Image

import main as cli
from lunglens.components.synthetic import make_ct_slice
from tests.helpers import tmpdir


class CliTests(unittest.TestCase):
    def test_demo_then_predict_then_errors(self):
        home = tmpdir() / "ws"
        with mock.patch.dict(os.environ, {}, clear=False):
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                self.assertEqual(cli.main(["--home", str(home), "demo", "--per-class", "14"]), 0)
            self.assertIn("Demo finished", out.getvalue())
            self.assertTrue((home / "artifacts" / "reports" / "scores.json").exists())

            scan = tmpdir() / "scan.png"
            Image.fromarray(make_ct_slice("large", np.random.default_rng(4))).save(scan)
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                code = cli.main(["--home", str(home), "predict", str(scan), "--explain", "--heatmap-dir", str(scan.parent)])
            self.assertEqual(code, 0)
            self.assertRegex(out.getvalue(), r"-> .+\(\d+\.\d%\)")
            self.assertTrue((scan.parent / "scan_heatmap.png").exists())

            # a fresh empty workspace: clean error message + exit code 1 instead of a traceback
            self.assertEqual(cli.main(["--home", str(tmpdir()), "train"]), 1)
            self.assertEqual(cli.main(["--home", str(tmpdir()), "ingest", "--local", "/no/such.zip"]), 1)

    def test_bare_invocation_runs_ingest_train_evaluate_in_order(self):
        calls = []
        with mock.patch("lunglens.pipeline.data_ingestion.main", side_effect=lambda *a, **k: calls.append("ingest")), \
                mock.patch("lunglens.pipeline.train.main", side_effect=lambda *a, **k: calls.append("train")), \
                mock.patch("lunglens.pipeline.evaluate.main", side_effect=lambda *a, **k: calls.append("evaluate") or {"accuracy": 1.0}), \
                contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cli.main(["--home", str(tmpdir())]), 0)   # no sub-command == `all`
            self.assertEqual(cli.main(["--home", str(tmpdir()), "train"]), 0)
        self.assertEqual(calls, ["ingest", "train", "evaluate", "train"])

    def test_ingest_flags_are_forwarded(self):
        with mock.patch("lunglens.pipeline.data_ingestion.main") as ingest:
            cli.main(["--home", str(tmpdir()), "ingest", "--local", "some.zip", "--force"])
        kwargs = ingest.call_args.kwargs
        self.assertEqual((kwargs["local"], kwargs["force"], kwargs["synthetic"]), ("some.zip", True, False))


if __name__ == "__main__":
    unittest.main()
