import shutil
import unittest
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image

from lunglens.components.data_ingestion import DataIngestion, safe_extract
from lunglens.components.dataset import build_index, class_weights, find_dataset_root, load_split, match_class
from lunglens.components.synthetic import generate_dataset
from lunglens.config.entity import DataIngestionConfig
from lunglens.exception import DatasetError
from tests.helpers import LocalServer, tmpdir, zip_dir

FULL = ["adenocarcinoma_left.lower.lobe_T2_N0_M0_Ib", "normal"]


def make_images(folder: Path, n=6, seed=0, ext="png"):
    rng = np.random.default_rng(seed)
    folder.mkdir(parents=True, exist_ok=True)
    for i in range(n):
        Image.fromarray(rng.integers(0, 255, (48, 48), dtype=np.uint8)).save(folder / f"{i}.{ext}")


def ingestion(root: Path, url=None, sha=None) -> DataIngestion:
    return DataIngestion(DataIngestionConfig(
        data_dir=root / "data", archive_path=root / "data" / "ds.zip", source_url=url,
        archive_sha256=sha, download_retries=1, download_timeout=10))


class DatasetTests(unittest.TestCase):
    def test_flat_split_is_stratified_and_disjoint(self):
        root = tmpdir()
        for c in FULL:
            make_images(root / "nested" / c, n=20)
        idx = build_index(root, 0.15, 0.15, seed=1)
        self.assertEqual(idx.layout, "flat")
        self.assertEqual(idx.class_names, sorted(FULL))
        self.assertEqual(len(idx.train) + len(idx.val) + len(idx.test), 40)
        paths = [p for split in (idx.train, idx.val, idx.test) for p, _ in split]
        self.assertEqual(len(paths), len(set(paths)))
        for split in (idx.train, idx.val, idx.test):
            self.assertEqual({y for _, y in split}, {0, 1})
        again = build_index(root, 0.15, 0.15, seed=1)
        self.assertEqual([p for p, _ in idx.test], [p for p, _ in again.test])  # deterministic

    def test_presplit_root_is_found_even_when_test_sorts_first(self):
        """Regression: 'test' < 'train' alphabetically must not be mistaken for the dataset root."""
        root = tmpdir()
        for split in ("train", "valid", "test"):
            for c in FULL:
                make_images(root / "Data" / split / c, n=4)
        self.assertEqual(find_dataset_root(root), root / "Data")
        idx = build_index(root, 0.15, 0.15, 1)
        self.assertEqual((idx.layout, len(idx.train), len(idx.val), len(idx.test)), ("pre-split", 8, 8, 8))

    def test_short_class_names_in_valid_are_matched(self):
        root = tmpdir()
        make_images(root / "train" / FULL[0], n=4)
        make_images(root / "train" / "normal", n=4)
        make_images(root / "valid" / "adenocarcinoma", n=3)   # short name, as in the public Kaggle dataset
        make_images(root / "valid" / "normal", n=3)
        idx = build_index(root, 0.15, 0.15, 1)
        self.assertEqual(sorted({y for _, y in idx.val}), [0, 1])
        self.assertEqual(match_class("adenocarcinoma", idx.class_names), 0)
        self.assertIsNone(match_class("unknown", idx.class_names))

    def test_errors_are_actionable(self):
        with self.assertRaisesRegex(DatasetError, "ingest --local"):
            build_index(tmpdir(), 0.15, 0.15, 1)
        root = tmpdir()
        make_images(root / "a", n=2)
        make_images(root / "b", n=20)
        with self.assertRaisesRegex(DatasetError, "at least 4 images"):
            build_index(root, 0.15, 0.15, 1)

    def test_macosx_and_hidden_folders_ignored(self):
        root = tmpdir()
        for c in FULL:
            make_images(root / "ds" / c, n=6)
        make_images(root / "__MACOSX" / "junk", n=3)
        make_images(root / ".hidden", n=3)
        self.assertEqual(find_dataset_root(root), root / "ds")

    def test_unreadable_images_are_skipped(self):
        root = tmpdir()
        for c in FULL:
            make_images(root / c, n=5)
        (root / "normal" / "broken.png").write_bytes(b"not an image")
        items = [(p, 0) for p in sorted((root / "normal").glob("*.png"))]
        x, y = load_split(items, (32, 32))
        self.assertEqual(len(x), 5)
        self.assertEqual(x.shape[1:], (32, 32))
        self.assertTrue(0.0 <= x.min() and x.max() <= 1.0)

    def test_class_weights_balance_rare_classes(self):
        w = class_weights([0] * 8 + [1] * 2, 2)
        self.assertGreater(w[1], w[0])
        self.assertAlmostEqual(w[0] * 8 + w[1] * 2, 10.0)


class IngestionTests(unittest.TestCase):
    def build_source(self):
        src = tmpdir() / "Chest-CT"
        for c in FULL:
            make_images(src / "train" / c, n=5)
            make_images(src / "valid" / c, n=3)
        return src

    def test_local_zip(self):
        src = self.build_source()
        archive = zip_dir(src, src.parent / "ds.zip")
        root = tmpdir()
        found = ingestion(root).run(local=str(archive))
        self.assertEqual(found.name, "Chest-CT")

    def test_local_folder_and_skip_when_present(self):
        src = self.build_source()
        root = tmpdir()
        ing = ingestion(root)
        first = ing.run(local=str(src))
        marker = first / "marker.txt"
        marker.write_text("x")
        self.assertEqual(ing.run(local=str(src)), first)          # already present -> untouched
        self.assertTrue(marker.exists())

    def test_missing_local_source(self):
        with self.assertRaisesRegex(DatasetError, "not found"):
            ingestion(tmpdir()).run(local="/nonexistent/x.zip")

    def test_zip_slip_is_blocked(self):
        evil = tmpdir() / "evil.zip"
        with zipfile.ZipFile(evil, "w") as zf:
            zf.writestr("../../escaped.txt", "boom")
        dest = tmpdir() / "out"
        with self.assertRaisesRegex(DatasetError, "Unsafe path"):
            safe_extract(evil, dest)
        self.assertFalse((dest.parent.parent / "escaped.txt").exists())

    def test_download_from_url_end_to_end(self):
        src = self.build_source()
        serve = tmpdir()
        zip_dir(src, serve / "dataset.zip")
        root = tmpdir()
        with LocalServer(serve) as s:
            found = ingestion(root, url=s.url("dataset.zip")).run()
        self.assertEqual(found.name, "Chest-CT")
        self.assertEqual(build_index(root / "data", 0.15, 0.15, 1).layout, "pre-split")

    def test_corrupt_download_is_deleted_with_helpful_message(self):
        serve = tmpdir()
        (serve / "bad.zip").write_bytes(b"this is not a zip" * 10)
        root = tmpdir()
        with LocalServer(serve) as s, self.assertRaisesRegex(DatasetError, "not a usable zip"):
            ingestion(root, url=s.url("bad.zip")).run()
        self.assertFalse((root / "data" / "ds.zip").exists())

    def test_no_url_gives_options(self):
        with self.assertRaisesRegex(DatasetError, "No download URL"):
            ingestion(tmpdir(), url=None).run()

    def test_synthetic(self):
        root = tmpdir()
        found = ingestion(root).run(synthetic=True, per_class=12)
        self.assertEqual(found.name, "synthetic_ct")
        idx = build_index(root / "data", 0.15, 0.15, 1)
        self.assertEqual(len(idx.class_names), 4)


class SyntheticTests(unittest.TestCase):
    def test_deterministic_per_seed(self):
        a, b = tmpdir(), tmpdir()
        generate_dataset(a, per_class=4, seed=5, presplit=False)
        generate_dataset(b, per_class=4, seed=5, presplit=False)
        f = sorted(a.rglob("*.png"))[0]
        self.assertTrue(np.array_equal(np.asarray(Image.open(f)), np.asarray(Image.open(b / f.relative_to(a)))))


if __name__ == "__main__":
    unittest.main()
