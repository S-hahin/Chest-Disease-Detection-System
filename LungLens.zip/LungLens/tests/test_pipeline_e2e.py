import unittest

import numpy as np
from PIL import Image

from lunglens.components.dataset import build_index
from lunglens.components.predictor import Predictor
from lunglens.components.synthetic import generate_dataset, make_ct_slice
from lunglens.exception import ImageQualityError, LungLensError, ModelNotReadyError
from lunglens.pipeline import evaluate, train
from lunglens.utils import load_json
from tests.helpers import manager, tmpdir, trained_workspace


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = trained_workspace()

    def test_training_artifacts_and_model_card(self):
        c = self.m.get_training_config()
        for p in (c.class_names_path, c.history_path, c.model_card_path, c.model_dir / "classic_model.joblib"):
            self.assertTrue(p.exists(), p)
        card = load_json(c.model_card_path)
        self.assertEqual(card["backend"], "classic")
        self.assertEqual(len(card["class_names"]), 4)
        self.assertEqual(card["cross_validation"]["folds"], 2)
        self.assertIn("train_fingerprint", card["dataset"])
        self.assertEqual(sum(card["dataset"]["class_counts_train"].values()), card["dataset"]["train_images"])

    def test_evaluation_outputs(self):
        e = self.m.get_evaluation_config()
        scores = load_json(e.scores_path)
        self.assertEqual(scores["evaluated_on"], "test")
        for k in ("accuracy", "balanced_accuracy", "macro_f1", "matthews_corrcoef", "log_loss",
                  "expected_calibration_error", "roc_auc_ovr_macro"):
            self.assertIn(k, scores)
        self.assertGreater(scores["accuracy"], 0.8)   # synthetic data is easy; a broken pipeline would be ~0.25
        self.assertEqual(len(scores["per_class"]), 4)
        self.assertTrue(e.confusion_matrix_path.stat().st_size > 1000)
        self.assertIn("precision", e.report_path.read_text())
        self.assertIn("evaluation", load_json(e.model_card_path))

    def test_evaluation_is_reproducible(self):
        a = evaluate.main(self.m)
        b = evaluate.main(self.m)
        self.assertEqual(a["accuracy"], b["accuracy"])
        self.assertEqual(a["log_loss"], b["log_loss"])

    def test_no_train_test_leakage(self):
        c = self.m.get_training_config()
        idx = build_index(c.data_dir, c.validation_split, c.test_split, c.seed)
        train_paths = {p for p, _ in idx.train}
        self.assertFalse(train_paths & {p for p, _ in idx.val + idx.test})

    def test_predictor(self):
        pred = Predictor(self.m.get_prediction_config())
        self.assertTrue(pred.is_ready)
        rng = np.random.default_rng(99)
        hits = 0
        for kind, prefix in (("normal", "normal"), ("large", "large"), ("squamous", "squamous"), ("adenocarcinoma", "adeno")):
            res = pred.predict(Image.fromarray(make_ct_slice(kind, rng)))
            hits += res["raw_label"].startswith(prefix)
            self.assertAlmostEqual(sum(p["probability"] for p in res["probabilities"]), 1.0, places=2)
            self.assertNotIn("explanation", res)
        self.assertGreaterEqual(hits, 3)

    def test_predictor_explain_and_uncertainty_flags(self):
        cfg = self.m.get_prediction_config()
        res = Predictor(cfg).predict(Image.fromarray(make_ct_slice("large", np.random.default_rng(1))), explain=True)
        self.assertEqual(res["explanation"]["method"], "occlusion-sensitivity")
        self.assertGreater(len(res["explanation"]["heatmap_png_base64"]), 100)
        from dataclasses import replace
        strict = Predictor(replace(cfg, confidence_threshold=1.01))
        out = strict.predict(Image.fromarray(make_ct_slice("normal", np.random.default_rng(2))))
        self.assertTrue(out["uncertain"])
        self.assertTrue(out["uncertain_reasons"])

    def test_predictor_rejects_bad_images(self):
        pred = Predictor(self.m.get_prediction_config())
        with self.assertRaises(ImageQualityError):
            pred.predict(Image.new("L", (128, 128), 90))

    def test_model_info(self):
        info = Predictor(self.m.get_prediction_config()).model_info()
        self.assertTrue(info["model_ready"])
        self.assertEqual(len(info["classes"]), 4)
        self.assertEqual(info["evaluation"]["evaluated_on"], "test")


class NotTrainedTests(unittest.TestCase):
    def test_predict_before_training(self):
        m = manager(tmpdir())
        pred = Predictor(m.get_prediction_config())
        self.assertFalse(pred.is_ready)
        self.assertEqual(pred.model_info(), {"model_ready": False})
        with self.assertRaises(ModelNotReadyError):
            pred.predict(Image.fromarray(make_ct_slice("normal", np.random.default_rng(0))))

    def test_evaluate_before_training(self):
        with self.assertRaisesRegex(LungLensError, "No trained model"):
            evaluate.main(manager(tmpdir()))

    def test_train_without_data(self):
        with self.assertRaisesRegex(LungLensError, "No image dataset"):
            train.main(manager(tmpdir()))


class VariantTests(unittest.TestCase):
    def test_flat_dataset_all_model_types(self):
        root = tmpdir()
        generate_dataset(root / "data" / "flat", per_class=20, seed=1, presplit=False)
        for model in ("svm", "random_forest", "gradient_boosting", "ensemble"):
            with self.subTest(model=model):
                m = manager(tmpdir(), classic={"MODEL": model})
                generate_dataset(m.root / "data" / "flat", per_class=20, seed=1, presplit=False)
                train.main(m)
                self.assertGreater(evaluate.main(m)["accuracy"], 0.7)

    def test_unknown_model_type(self):
        m = manager(tmpdir(), classic={"MODEL": "magic"})
        generate_dataset(m.root / "data" / "d", per_class=12, presplit=False)
        with self.assertRaisesRegex(LungLensError, "MODEL must be one of"):
            train.main(m)

    def test_changed_dataset_triggers_warning_not_crash(self):
        m = manager(tmpdir())
        generate_dataset(m.root / "data" / "d", per_class=12, presplit=False)
        train.main(m)
        # same data, different split parameters -> different training split than the model was trained on
        m2 = manager(m.root, VALIDATION_SPLIT=0.25)
        with self.assertLogs("lunglens", level="WARNING") as logs:
            evaluate.main(m2)
        self.assertTrue(any("differs" in line for line in logs.output))


if __name__ == "__main__":
    unittest.main()
