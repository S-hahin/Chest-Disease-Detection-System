import base64
import io
import os
import unittest
from unittest import mock

import numpy as np
from PIL import Image

from app import create_app
from lunglens.components.predictor import Predictor
from lunglens.components.synthetic import make_ct_slice
from tests.helpers import manager, tmpdir, trained_workspace


def png_bytes(kind="normal", seed=0, size=128) -> bytes:
    buf = io.BytesIO()
    Image.fromarray(make_ct_slice(kind, np.random.default_rng(seed), size)).save(buf, format="PNG")
    return buf.getvalue()


def upload(name="scan.png", data=None, field="file"):
    return {field: (io.BytesIO(data if data is not None else png_bytes()), name)}


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.predictor = Predictor(trained_workspace().get_prediction_config())

    def setUp(self):
        self.client = create_app(self.predictor).test_client()

    def post(self, url="/predict", **kw):
        return self.client.post(url, content_type="multipart/form-data", **kw)

    def test_health_and_model_info(self):
        self.assertEqual(self.client.get("/health").get_json(), {"status": "ok", "model_ready": True})
        info = self.client.get("/model-info").get_json()
        self.assertTrue(info["model_ready"])
        self.assertEqual(info["backend"], "classic")

    def test_home_page(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"LungLens", r.data)

    def test_predict_multipart(self):
        r = self.post(data=upload(data=png_bytes("large", 5)))
        body = r.get_json()
        self.assertEqual(r.status_code, 200, body)
        self.assertIn("confidence", body)
        self.assertNotIn("explanation", body)
        self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")

    def test_predict_json_base64_and_data_url(self):
        b64 = base64.b64encode(png_bytes()).decode()
        for payload in (b64, "data:image/png;base64," + b64):
            r = self.client.post("/predict", json={"image": payload})
            self.assertEqual(r.status_code, 200, r.get_json())

    def test_predict_with_explanation(self):
        r = self.post("/predict?explain=1", data=upload())
        self.assertEqual(r.status_code, 200)
        self.assertIn("heatmap_png_base64", r.get_json()["explanation"])

    def test_client_errors(self):
        self.assertEqual(self.post(data=upload(data=b"not an image")).status_code, 400)
        self.assertEqual(self.client.post("/predict").status_code, 400)
        self.assertEqual(self.client.post("/predict", json={"image": "%%%not-base64%%%"}).status_code, 400)
        self.assertEqual(self.client.get("/predict").status_code, 405)
        self.assertEqual(self.client.get("/nope").status_code, 404)
        self.assertIn("error", self.client.get("/nope").get_json())

    def test_unsuitable_images_get_422(self):
        buf = io.BytesIO()
        Image.new("L", (200, 200), 128).save(buf, format="PNG")
        r = self.post(data=upload(data=buf.getvalue()))
        self.assertEqual(r.status_code, 422)
        self.assertEqual(r.get_json()["code"], "image_rejected")

    def test_upload_size_limit(self):
        app = create_app(self.predictor)
        app.config["MAX_CONTENT_LENGTH"] = 1000
        r = app.test_client().post("/predict", data=upload(data=b"x" * 5000), content_type="multipart/form-data")
        self.assertEqual(r.status_code, 413)
        self.assertIn("error", r.get_json())

    def test_batch(self):
        data = {"files": [(io.BytesIO(png_bytes("normal", 1)), "a.png"), (io.BytesIO(b"junk"), "b.png"),
                          (io.BytesIO(png_bytes("large", 2)), "c.png")]}
        body = self.post("/predict/batch", data=data).get_json()
        self.assertEqual(body["count"], 3)
        self.assertIn("label", body["results"][0])
        self.assertIn("error", body["results"][1])
        self.assertIn("label", body["results"][2])
        self.assertEqual(self.client.post("/predict/batch").status_code, 400)
        too_many = {"files": [(io.BytesIO(png_bytes()), f"{i}.png") for i in range(17)]}
        self.assertEqual(self.post("/predict/batch", data=too_many).status_code, 400)

    def test_api_key_protects_post_only(self):
        with mock.patch.dict(os.environ, {"LUNGLENS_API_KEY": "s3cret"}):
            client = create_app(self.predictor).test_client()
        self.assertEqual(client.get("/health").status_code, 200)
        self.assertEqual(client.post("/predict", data=upload(), content_type="multipart/form-data").status_code, 401)
        bad = client.post("/predict", data=upload(), content_type="multipart/form-data", headers={"X-API-Key": "nope"})
        self.assertEqual(bad.status_code, 401)
        ok = client.post("/predict", data=upload(), content_type="multipart/form-data", headers={"X-API-Key": "s3cret"})
        self.assertEqual(ok.status_code, 200)

    def test_cors_is_off_by_default_and_configurable(self):
        self.assertNotIn("Access-Control-Allow-Origin", self.client.get("/health", headers={"Origin": "http://a.example"}).headers)
        with mock.patch.dict(os.environ, {"LUNGLENS_CORS_ORIGINS": "http://a.example"}):
            client = create_app(self.predictor).test_client()
        self.assertEqual(client.get("/health", headers={"Origin": "http://a.example"}).headers["Access-Control-Allow-Origin"], "http://a.example")
        self.assertNotIn("Access-Control-Allow-Origin", client.get("/health", headers={"Origin": "http://evil.example"}).headers)

    def test_503_when_model_missing(self):
        client = create_app(Predictor(manager(tmpdir()).get_prediction_config())).test_client()
        self.assertEqual(client.get("/health").get_json()["model_ready"], False)
        r = client.post("/predict", data=upload(), content_type="multipart/form-data")
        self.assertEqual(r.status_code, 503)
        self.assertIn("main.py", r.get_json()["error"])


if __name__ == "__main__":
    unittest.main()
