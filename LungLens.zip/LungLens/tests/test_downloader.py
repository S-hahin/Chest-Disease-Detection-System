import http.server
import unittest

from lunglens.components.downloader import _parse_drive_confirmation, download_file, normalize_url
from lunglens.exception import DownloadError
from lunglens.utils import sha256_file
from tests.helpers import LocalServer, QuietHandler, tmpdir


class UrlTests(unittest.TestCase):
    def test_drive_share_links_become_direct_links(self):
        for url in ("https://drive.google.com/file/d/ABC_123-x/view?usp=sharing",
                    "https://drive.google.com/open?id=ABC_123-x",
                    "https://drive.google.com/uc?export=download&id=ABC_123-x"):
            self.assertEqual(normalize_url(url), "https://drive.google.com/uc?export=download&id=ABC_123-x")

    def test_other_urls_untouched(self):
        self.assertEqual(normalize_url("https://example.com/a.zip"), "https://example.com/a.zip")


class DownloadTests(unittest.TestCase):
    def setUp(self):
        self.srv_dir = tmpdir()
        (self.srv_dir / "data.zip").write_bytes(b"PK-not-really-but-bytes" * 1000)
        (self.srv_dir / "page.html").write_text("<html>Sign in to continue</html>")

    def test_download_and_checksum(self):
        good = sha256_file(self.srv_dir / "data.zip")
        with LocalServer(self.srv_dir) as s:
            out = download_file(s.url("data.zip"), tmpdir() / "x" / "d.zip", retries=1, expected_sha256=good)
            self.assertEqual(sha256_file(out), good)
            self.assertFalse(out.with_name("d.zip.part").exists())
            with self.assertRaisesRegex(DownloadError, "Checksum mismatch"):
                download_file(s.url("data.zip"), tmpdir() / "d.zip", retries=1, expected_sha256="0" * 64)

    def test_html_page_is_not_accepted_as_a_file(self):
        dest = tmpdir() / "d.zip"
        with LocalServer(self.srv_dir) as s, self.assertRaisesRegex(DownloadError, "web page instead of a file"):
            download_file(s.url("page.html"), dest, retries=1)
        self.assertFalse(dest.exists())

    def test_404_fails_fast_without_retrying(self):
        hits = []

        class Counting(QuietHandler):
            def do_GET(self):
                hits.append(1)
                super().do_GET()

        with LocalServer(self.srv_dir, Counting) as s, self.assertRaisesRegex(DownloadError, "HTTP 404"):
            download_file(s.url("nope.zip"), tmpdir() / "d.zip", retries=3, backoff=0.01)
        self.assertEqual(len(hits), 1)

    def test_transient_503_is_retried(self):
        state = {"n": 0}

        class Flaky(QuietHandler):
            def do_GET(self):
                state["n"] += 1
                if state["n"] < 3:
                    self.send_error(503)
                else:
                    super().do_GET()

        with LocalServer(self.srv_dir, Flaky) as s:
            out = download_file(s.url("data.zip"), tmpdir() / "d.zip", retries=3, backoff=0.01)
        self.assertEqual(state["n"], 3)
        self.assertTrue(out.exists())

    def test_gives_up_after_retries(self):
        class Always503(QuietHandler):
            def do_GET(self):
                self.send_error(503)

        with LocalServer(self.srv_dir, Always503) as s, self.assertRaisesRegex(DownloadError, "after 2 attempts"):
            download_file(s.url("data.zip"), tmpdir() / "d.zip", retries=2, backoff=0.01)


class DriveConfirmationTests(unittest.TestCase):
    PAGE = ('<form id="download-form" action="https://drive.usercontent.google.com/download" method="get">'
            '<input type="hidden" name="id" value="FILEID"><input type="hidden" name="confirm" value="t">'
            '<input type="hidden" name="uuid" value="u-1"></form>')

    def test_form_is_parsed(self):
        url = _parse_drive_confirmation(self.PAGE, "https://drive.google.com/uc")
        self.assertTrue(url.startswith("https://drive.usercontent.google.com/download?"))
        for part in ("id=FILEID", "confirm=t", "uuid=u-1"):
            self.assertIn(part, url)

    def test_plain_html_is_not_mistaken_for_confirmation(self):
        self.assertIsNone(_parse_drive_confirmation("<html>login</html>", "https://x"))

    def test_confirmation_page_is_followed_end_to_end(self):
        """Emulates Drive's 'large file' interstitial with a local server."""
        srv_dir = tmpdir()
        (srv_dir / "real.zip").write_bytes(b"payload" * 100)
        server = {}

        class FakeDrive(QuietHandler):
            def do_GET(self):
                if self.path.startswith("/start"):
                    body = (f'<form id="download-form" action="http://127.0.0.1:{server["port"]}/real.zip">'
                            '<input type="hidden" name="confirm" value="t"></form>').encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                else:
                    self.path = self.path.split("?")[0]
                    super().do_GET()

        with LocalServer(srv_dir, FakeDrive) as s:
            server["port"] = s.port
            out = download_file(s.url("start"), tmpdir() / "d.zip", retries=1)
        self.assertEqual(out.read_bytes(), b"payload" * 100)


if __name__ == "__main__":
    unittest.main()
