import unittest

import numpy as np
from PIL import Image

from lunglens.components.explain import occlusion_heatmap, overlay_png_base64
from lunglens.components.features import HandcraftedFeatures
from lunglens.components.metrics import entropy, expected_calibration_error
from lunglens.components.preprocessing import stretch_contrast, to_gray_array
from lunglens.components.quality import assess_image
from lunglens.components.synthetic import make_ct_slice


class PreprocessingTests(unittest.TestCase):
    def test_output_contract(self):
        im = Image.fromarray(np.random.default_rng(0).integers(0, 255, (90, 60, 3), dtype=np.uint8))
        a = to_gray_array(im, (64, 48))
        self.assertEqual((a.shape, a.dtype), ((64, 48), np.float32))
        self.assertTrue(0 <= a.min() and a.max() <= 1)

    def test_16bit_scans_are_scaled_not_clipped(self):
        arr = (np.linspace(0, 60000, 64 * 64).reshape(64, 64)).astype(np.uint16)
        a = to_gray_array(Image.fromarray(arr), (32, 32), normalize_contrast=False)
        self.assertLess(a.min(), 0.05)
        self.assertGreater(a.max(), 0.95)

    def test_rgba_transparency_becomes_black(self):
        im = Image.new("RGBA", (40, 40), (255, 255, 255, 0))
        self.assertEqual(float(to_gray_array(im, (32, 32), False).max()), 0.0)

    def test_contrast_stretch(self):
        low = np.random.default_rng(0).uniform(0.4, 0.5, (32, 32)).astype(np.float32)
        s = stretch_contrast(low)
        self.assertGreater(s.max() - s.min(), 0.9)
        flat = np.full((8, 8), 0.3, dtype=np.float32)
        self.assertTrue(np.array_equal(stretch_contrast(flat), flat))  # constant image untouched


class QualityTests(unittest.TestCase):
    def test_good_ct_like_image_passes(self):
        rep = assess_image(Image.fromarray(make_ct_slice("normal", np.random.default_rng(0), 128)))
        self.assertTrue(rep.ok)
        self.assertEqual(rep.reasons, [])

    def test_rejections(self):
        cases = {
            "small": Image.new("L", (30, 30)),
            "blank": Image.new("L", (128, 128), 100),
            "colour": Image.fromarray(np.dstack([np.full((100, 100), v, np.uint8) for v in (250, 20, 20)])
                                      + np.random.default_rng(0).integers(0, 5, (100, 100, 3), dtype=np.uint8)),
        }
        for name, im in cases.items():
            with self.subTest(name):
                self.assertFalse(assess_image(im).ok)

    def test_aspect_ratio_warning_only(self):
        wide = Image.fromarray(np.random.default_rng(0).integers(0, 255, (80, 400), dtype=np.uint8))
        rep = assess_image(wide)
        self.assertTrue(rep.ok)
        self.assertTrue(any("aspect" in w for w in rep.warnings))


class FeatureTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(0)
        self.batch = np.stack([make_ct_slice(k, rng).astype(np.float32) / 255 for k in ("normal", "large", "squamous")])

    def test_shape_finite_deterministic(self):
        f = HandcraftedFeatures()
        a, b = f.transform(self.batch), f.transform(self.batch)
        self.assertEqual(a.shape[0], 3)
        self.assertTrue(np.isfinite(a).all())
        self.assertTrue(np.array_equal(a, b))

    def test_different_images_differ_and_constant_image_is_safe(self):
        f = HandcraftedFeatures()
        feats = f.transform(self.batch)
        self.assertFalse(np.allclose(feats[0], feats[1]))
        self.assertTrue(np.isfinite(f.transform(np.zeros((1, 128, 128), np.float32))).all())


class ExplainTests(unittest.TestCase):
    def test_heatmap_points_at_the_region_that_matters(self):
        gray = np.random.default_rng(0).uniform(0.2, 0.3, (64, 64)).astype(np.float32)
        gray[8:24, 40:56] = 1.0                                   # bright "lesion" in the upper right

        def score(batch):                                          # toy model: looks only at that region
            return batch[:, 8:24, 40:56].mean(axis=(1, 2))

        heat = occlusion_heatmap(score, gray, grid=8)
        self.assertEqual(heat.shape, gray.shape)
        self.assertTrue(0 <= heat.min() and heat.max() <= 1.0)
        peak = np.unravel_index(heat.argmax(), heat.shape)
        self.assertTrue(8 <= peak[0] < 24 and 40 <= peak[1] < 56, peak)
        self.assertLess(heat[40:, :32].mean(), 0.05)               # opposite corner is irrelevant

    def test_overlay_is_a_png(self):
        import base64
        import io
        png = base64.b64decode(overlay_png_base64(np.zeros((32, 32), np.float32), np.ones((32, 32))))
        self.assertEqual(Image.open(io.BytesIO(png)).format, "PNG")


class MetricTests(unittest.TestCase):
    def test_entropy_bounds(self):
        self.assertAlmostEqual(entropy([1, 0, 0, 0]), 0.0, places=6)
        self.assertAlmostEqual(entropy([0.25] * 4), 2.0, places=6)

    def test_ece(self):
        perfect = np.array([[1.0, 0.0], [0.0, 1.0]])
        self.assertAlmostEqual(expected_calibration_error(perfect, np.array([0, 1])), 0.0)
        overconfident = np.array([[1.0, 0.0], [1.0, 0.0]])
        self.assertAlmostEqual(expected_calibration_error(overconfident, np.array([0, 1])), 0.5)


if __name__ == "__main__":
    unittest.main()
