from setuptools import find_packages, setup

setup(
    name="lunglens",
    version="2.0.0",
    description="Chest CT slice classification: classic ML + optional transfer learning, API and web UI",
    packages=find_packages(exclude=("tests", "tests.*")),
    python_requires=">=3.8,<3.13",
)
